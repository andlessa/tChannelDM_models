# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 10.4.0 for Mac OS X x86 (64-bit) (February 26, 2016)
# Date: Mon 18 Jan 2021 15:58:17


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



