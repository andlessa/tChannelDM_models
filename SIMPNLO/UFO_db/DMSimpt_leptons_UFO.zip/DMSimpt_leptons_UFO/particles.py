# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 10.4.0 for Mac OS X x86 (64-bit) (February 26, 2016)
# Date: Mon 18 Jan 2021 15:58:17


from __future__ import division
from object_library import all_particles, Particle
import parameters as Param

import propagators as Prop

a = Particle(pdg_code = 22,
             name = 'a',
             antiname = 'a',
             spin = 3,
             color = 1,
             mass = Param.ZERO,
             width = Param.ZERO,
             texname = 'a',
             antitexname = 'a',
             charge = 0,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

Z = Particle(pdg_code = 23,
             name = 'Z',
             antiname = 'Z',
             spin = 3,
             color = 1,
             mass = Param.MZ,
             width = Param.WZ,
             texname = 'Z',
             antitexname = 'Z',
             charge = 0,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

W__plus__ = Particle(pdg_code = 24,
                     name = 'W+',
                     antiname = 'W-',
                     spin = 3,
                     color = 1,
                     mass = Param.MW,
                     width = Param.WW,
                     texname = 'W+',
                     antitexname = 'W-',
                     charge = 1,
                     GhostNumber = 0,
                     LeptonNumber = 0,
                     Y = 0)

W__minus__ = W__plus__.anti()

g = Particle(pdg_code = 21,
             name = 'g',
             antiname = 'g',
             spin = 3,
             color = 8,
             mass = Param.ZERO,
             width = Param.ZERO,
             texname = 'g',
             antitexname = 'g',
             charge = 0,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

ghA = Particle(pdg_code = 9000001,
               name = 'ghA',
               antiname = 'ghA~',
               spin = -1,
               color = 1,
               mass = Param.ZERO,
               width = Param.ZERO,
               texname = 'ghA',
               antitexname = 'ghA~',
               charge = 0,
               GhostNumber = 1,
               LeptonNumber = 0,
               Y = 0)

ghA__tilde__ = ghA.anti()

ghZ = Particle(pdg_code = 9000002,
               name = 'ghZ',
               antiname = 'ghZ~',
               spin = -1,
               color = 1,
               mass = Param.MZ,
               width = Param.WZ,
               texname = 'ghZ',
               antitexname = 'ghZ~',
               charge = 0,
               GhostNumber = 1,
               LeptonNumber = 0,
               Y = 0)

ghZ__tilde__ = ghZ.anti()

ghWp = Particle(pdg_code = 9000003,
                name = 'ghWp',
                antiname = 'ghWp~',
                spin = -1,
                color = 1,
                mass = Param.MW,
                width = Param.WW,
                texname = 'ghWp',
                antitexname = 'ghWp~',
                charge = 1,
                GhostNumber = 1,
                LeptonNumber = 0,
                Y = 0)

ghWp__tilde__ = ghWp.anti()

ghWm = Particle(pdg_code = 9000004,
                name = 'ghWm',
                antiname = 'ghWm~',
                spin = -1,
                color = 1,
                mass = Param.MW,
                width = Param.WW,
                texname = 'ghWm',
                antitexname = 'ghWm~',
                charge = -1,
                GhostNumber = 1,
                LeptonNumber = 0,
                Y = 0)

ghWm__tilde__ = ghWm.anti()

ghG = Particle(pdg_code = 82,
               name = 'ghG',
               antiname = 'ghG~',
               spin = -1,
               color = 8,
               mass = Param.ZERO,
               width = Param.ZERO,
               texname = 'ghG',
               antitexname = 'ghG~',
               charge = 0,
               GhostNumber = 1,
               LeptonNumber = 0,
               Y = 0)

ghG__tilde__ = ghG.anti()

ve = Particle(pdg_code = 12,
              name = 've',
              antiname = 've~',
              spin = 2,
              color = 1,
              mass = Param.ZERO,
              width = Param.ZERO,
              texname = 've',
              antitexname = 've~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 1,
              Y = 0)

ve__tilde__ = ve.anti()

vm = Particle(pdg_code = 14,
              name = 'vm',
              antiname = 'vm~',
              spin = 2,
              color = 1,
              mass = Param.ZERO,
              width = Param.ZERO,
              texname = 'vm',
              antitexname = 'vm~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 1,
              Y = 0)

vm__tilde__ = vm.anti()

vt = Particle(pdg_code = 16,
              name = 'vt',
              antiname = 'vt~',
              spin = 2,
              color = 1,
              mass = Param.ZERO,
              width = Param.ZERO,
              texname = 'vt',
              antitexname = 'vt~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 1,
              Y = 0)

vt__tilde__ = vt.anti()

e__minus__ = Particle(pdg_code = 11,
                      name = 'e-',
                      antiname = 'e+',
                      spin = 2,
                      color = 1,
                      mass = Param.Me,
                      width = Param.ZERO,
                      texname = 'e-',
                      antitexname = 'e+',
                      charge = -1,
                      GhostNumber = 0,
                      LeptonNumber = 1,
                      Y = 0)

e__plus__ = e__minus__.anti()

mu__minus__ = Particle(pdg_code = 13,
                       name = 'mu-',
                       antiname = 'mu+',
                       spin = 2,
                       color = 1,
                       mass = Param.MMU,
                       width = Param.ZERO,
                       texname = 'mu-',
                       antitexname = 'mu+',
                       charge = -1,
                       GhostNumber = 0,
                       LeptonNumber = 1,
                       Y = 0)

mu__plus__ = mu__minus__.anti()

ta__minus__ = Particle(pdg_code = 15,
                       name = 'ta-',
                       antiname = 'ta+',
                       spin = 2,
                       color = 1,
                       mass = Param.MTA,
                       width = Param.ZERO,
                       texname = 'ta-',
                       antitexname = 'ta+',
                       charge = -1,
                       GhostNumber = 0,
                       LeptonNumber = 1,
                       Y = 0)

ta__plus__ = ta__minus__.anti()

u = Particle(pdg_code = 2,
             name = 'u',
             antiname = 'u~',
             spin = 2,
             color = 3,
             mass = Param.MU,
             width = Param.ZERO,
             texname = 'u',
             antitexname = 'u~',
             charge = 2/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

u__tilde__ = u.anti()

c = Particle(pdg_code = 4,
             name = 'c',
             antiname = 'c~',
             spin = 2,
             color = 3,
             mass = Param.MC,
             width = Param.ZERO,
             texname = 'c',
             antitexname = 'c~',
             charge = 2/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

c__tilde__ = c.anti()

t = Particle(pdg_code = 6,
             name = 't',
             antiname = 't~',
             spin = 2,
             color = 3,
             mass = Param.MT,
             width = Param.WT,
             texname = 't',
             antitexname = 't~',
             charge = 2/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

t__tilde__ = t.anti()

d = Particle(pdg_code = 1,
             name = 'd',
             antiname = 'd~',
             spin = 2,
             color = 3,
             mass = Param.MD,
             width = Param.ZERO,
             texname = 'd',
             antitexname = 'd~',
             charge = -1/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

d__tilde__ = d.anti()

s = Particle(pdg_code = 3,
             name = 's',
             antiname = 's~',
             spin = 2,
             color = 3,
             mass = Param.MS,
             width = Param.ZERO,
             texname = 's',
             antitexname = 's~',
             charge = -1/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

s__tilde__ = s.anti()

b = Particle(pdg_code = 5,
             name = 'b',
             antiname = 'b~',
             spin = 2,
             color = 3,
             mass = Param.MB,
             width = Param.ZERO,
             texname = 'b',
             antitexname = 'b~',
             charge = -1/3,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

b__tilde__ = b.anti()

H = Particle(pdg_code = 25,
             name = 'H',
             antiname = 'H',
             spin = 1,
             color = 1,
             mass = Param.MH,
             width = Param.WH,
             texname = 'H',
             antitexname = 'H',
             charge = 0,
             GhostNumber = 0,
             LeptonNumber = 0,
             Y = 0)

G0 = Particle(pdg_code = 250,
              name = 'G0',
              antiname = 'G0',
              spin = 1,
              color = 1,
              mass = Param.MZ,
              width = Param.WZ,
              texname = 'G0',
              antitexname = 'G0',
              goldstone = True,
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

G__plus__ = Particle(pdg_code = 251,
                     name = 'G+',
                     antiname = 'G-',
                     spin = 1,
                     color = 1,
                     mass = Param.MW,
                     width = Param.WW,
                     texname = 'G+',
                     antitexname = 'G-',
                     goldstone = True,
                     charge = 1,
                     GhostNumber = 0,
                     LeptonNumber = 0,
                     Y = 0)

G__minus__ = G__plus__.anti()

Xm = Particle(pdg_code = 52,
              name = 'Xm',
              antiname = 'Xm',
              spin = 2,
              color = 1,
              mass = Param.MXm,
              width = Param.ZERO,
              texname = 'Xm',
              antitexname = 'Xm',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xd = Particle(pdg_code = 57,
              name = 'Xd',
              antiname = 'Xd~',
              spin = 2,
              color = 1,
              mass = Param.MXd,
              width = Param.ZERO,
              texname = 'Xd',
              antitexname = 'Xd~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xd__tilde__ = Xd.anti()

Xs = Particle(pdg_code = 51,
              name = 'Xs',
              antiname = 'Xs',
              spin = 1,
              color = 1,
              mass = Param.MXs,
              width = Param.ZERO,
              texname = 'Xs',
              antitexname = 'Xs',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xc = Particle(pdg_code = 56,
              name = 'Xc',
              antiname = 'Xc~',
              spin = 1,
              color = 1,
              mass = Param.MXc,
              width = Param.ZERO,
              texname = 'Xc',
              antitexname = 'Xc~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xc__tilde__ = Xc.anti()

Xv = Particle(pdg_code = 53,
              name = 'Xv',
              antiname = 'Xv',
              spin = 3,
              color = 1,
              mass = Param.MXv,
              width = Param.ZERO,
              texname = 'Xv',
              antitexname = 'Xv',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xw = Particle(pdg_code = 58,
              name = 'Xw',
              antiname = 'Xw~',
              spin = 3,
              color = 1,
              mass = Param.MXw,
              width = Param.ZERO,
              texname = 'Xw',
              antitexname = 'Xw~',
              charge = 0,
              GhostNumber = 0,
              LeptonNumber = 0,
              Y = 0)

Xw__tilde__ = Xw.anti()

YS3Le1 = Particle(pdg_code = 5930012,
                  name = 'YS3Le1',
                  antiname = 'YS3Le1~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Le1,
                  width = Param.WYS3Le1,
                  texname = 'YS3Le1',
                  antitexname = 'YS3Le1~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Le1__tilde__ = YS3Le1.anti()

YS3Le2 = Particle(pdg_code = 5930014,
                  name = 'YS3Le2',
                  antiname = 'YS3Le2~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Le2,
                  width = Param.WYS3Le2,
                  texname = 'YS3Le2',
                  antitexname = 'YS3Le2~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Le2__tilde__ = YS3Le2.anti()

YS3Le3 = Particle(pdg_code = 5930016,
                  name = 'YS3Le3',
                  antiname = 'YS3Le3~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Le3,
                  width = Param.WYS3Le3,
                  texname = 'YS3Le3',
                  antitexname = 'YS3Le3~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Le3__tilde__ = YS3Le3.anti()

YS3Ln1 = Particle(pdg_code = 5930011,
                  name = 'YS3Ln1',
                  antiname = 'YS3Ln1~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Ln1,
                  width = Param.WYS3Ln1,
                  texname = 'YS3Ln1',
                  antitexname = 'YS3Ln1~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Ln1__tilde__ = YS3Ln1.anti()

YS3Ln2 = Particle(pdg_code = 5930013,
                  name = 'YS3Ln2',
                  antiname = 'YS3Ln2~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Ln2,
                  width = Param.WYS3Ln2,
                  texname = 'YS3Ln2',
                  antitexname = 'YS3Ln2~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Ln2__tilde__ = YS3Ln2.anti()

YS3Ln3 = Particle(pdg_code = 5930015,
                  name = 'YS3Ln3',
                  antiname = 'YS3Ln3~',
                  spin = 1,
                  color = 1,
                  mass = Param.MYS3Ln3,
                  width = Param.WYS3Ln3,
                  texname = 'YS3Ln3',
                  antitexname = 'YS3Ln3~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YS3Ln3__tilde__ = YS3Ln3.anti()

YS3e1 = Particle(pdg_code = 5940011,
                 name = 'YS3e1',
                 antiname = 'YS3e1~',
                 spin = 1,
                 color = 1,
                 mass = Param.MYS3e1,
                 width = Param.WYS3e1,
                 texname = 'YS3e1',
                 antitexname = 'YS3e1~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YS3e1__tilde__ = YS3e1.anti()

YS3e2 = Particle(pdg_code = 5940013,
                 name = 'YS3e2',
                 antiname = 'YS3e2~',
                 spin = 1,
                 color = 1,
                 mass = Param.MYS3e2,
                 width = Param.WYS3e2,
                 texname = 'YS3e2',
                 antitexname = 'YS3e2~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YS3e2__tilde__ = YS3e2.anti()

YS3e3 = Particle(pdg_code = 5940015,
                 name = 'YS3e3',
                 antiname = 'YS3e3~',
                 spin = 1,
                 color = 1,
                 mass = Param.MYS3e3,
                 width = Param.WYS3e3,
                 texname = 'YS3e3',
                 antitexname = 'YS3e3~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YS3e3__tilde__ = YS3e3.anti()

YF3Le1 = Particle(pdg_code = 5910012,
                  name = 'YF3Le1',
                  antiname = 'YF3Le1~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Le1,
                  width = Param.WYF3Le1,
                  texname = 'YF3Le1',
                  antitexname = 'YF3Le1~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Le1__tilde__ = YF3Le1.anti()

YF3Le2 = Particle(pdg_code = 5910014,
                  name = 'YF3Le2',
                  antiname = 'YF3Le2~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Le2,
                  width = Param.WYF3Le2,
                  texname = 'YF3Le2',
                  antitexname = 'YF3Le2~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Le2__tilde__ = YF3Le2.anti()

YF3Le3 = Particle(pdg_code = 5910016,
                  name = 'YF3Le3',
                  antiname = 'YF3Le3~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Le3,
                  width = Param.WYF3Le3,
                  texname = 'YF3Le3',
                  antitexname = 'YF3Le3~',
                  charge = -1,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Le3__tilde__ = YF3Le3.anti()

YF3Ln1 = Particle(pdg_code = 5910011,
                  name = 'YF3Ln1',
                  antiname = 'YF3Ln1~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Ln1,
                  width = Param.WYF3Ln1,
                  texname = 'YF3Ln1',
                  antitexname = 'YF3Ln1~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Ln1__tilde__ = YF3Ln1.anti()

YF3Ln2 = Particle(pdg_code = 5910013,
                  name = 'YF3Ln2',
                  antiname = 'YF3Ln2~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Ln2,
                  width = Param.WYF3Ln2,
                  texname = 'YF3Ln2',
                  antitexname = 'YF3Ln2~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Ln2__tilde__ = YF3Ln2.anti()

YF3Ln3 = Particle(pdg_code = 5910015,
                  name = 'YF3Ln3',
                  antiname = 'YF3Ln3~',
                  spin = 2,
                  color = 1,
                  mass = Param.MYF3Ln3,
                  width = Param.WYF3Ln3,
                  texname = 'YF3Ln3',
                  antitexname = 'YF3Ln3~',
                  charge = 0,
                  GhostNumber = 0,
                  LeptonNumber = 0,
                  Y = 0)

YF3Ln3__tilde__ = YF3Ln3.anti()

YF3e1 = Particle(pdg_code = 5920011,
                 name = 'YF3e1',
                 antiname = 'YF3e1~',
                 spin = 2,
                 color = 1,
                 mass = Param.MYF3e1,
                 width = Param.WYF3e1,
                 texname = 'YF3e1',
                 antitexname = 'YF3e1~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YF3e1__tilde__ = YF3e1.anti()

YF3e2 = Particle(pdg_code = 5920013,
                 name = 'YF3e2',
                 antiname = 'YF3e2~',
                 spin = 2,
                 color = 1,
                 mass = Param.MYF3e2,
                 width = Param.WYF3e2,
                 texname = 'YF3e2',
                 antitexname = 'YF3e2~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YF3e2__tilde__ = YF3e2.anti()

YF3e3 = Particle(pdg_code = 5920015,
                 name = 'YF3e3',
                 antiname = 'YF3e3~',
                 spin = 2,
                 color = 1,
                 mass = Param.MYF3e3,
                 width = Param.WYF3e3,
                 texname = 'YF3e3',
                 antitexname = 'YF3e3~',
                 charge = -1,
                 GhostNumber = 0,
                 LeptonNumber = 0,
                 Y = -1)

YF3e3__tilde__ = YF3e3.anti()

