# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 10.4.0 for Mac OS X x86 (64-bit) (February 26, 2016)
# Date: Mon 18 Jan 2021 15:58:17


from object_library import all_decays, Decay
import particles as P


Decay_b = Decay(name = 'Decay_b',
                particle = P.b,
                partial_widths = {(P.W__minus__,P.t):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MB)**3)'})

Decay_c = Decay(name = 'Decay_c',
                particle = P.c,
                partial_widths = {(P.W__plus__,P.s):'(((3*ee**2*MC**2)/(2.*sw**2) + (3*ee**2*MS**2)/(2.*sw**2) + (3*ee**2*MC**4)/(2.*MW**2*sw**2) - (3*ee**2*MC**2*MS**2)/(MW**2*sw**2) + (3*ee**2*MS**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MC**4 - 2*MC**2*MS**2 + MS**4 - 2*MC**2*MW**2 - 2*MS**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MC)**3)'})

Decay_d = Decay(name = 'Decay_d',
                particle = P.d,
                partial_widths = {(P.W__minus__,P.u):'(((3*ee**2*MD**2)/(2.*sw**2) + (3*ee**2*MU**2)/(2.*sw**2) + (3*ee**2*MD**4)/(2.*MW**2*sw**2) - (3*ee**2*MD**2*MU**2)/(MW**2*sw**2) + (3*ee**2*MU**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MD**4 - 2*MD**2*MU**2 + MU**4 - 2*MD**2*MW**2 - 2*MU**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MD)**3)'})

Decay_e__minus__ = Decay(name = 'Decay_e__minus__',
                         particle = P.e__minus__,
                         partial_widths = {(P.W__minus__,P.ve):'((Me**2 - MW**2)*((ee**2*Me**2)/(2.*sw**2) + (ee**2*Me**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xc__tilde__,P.YF3e1):'((lamF3e1x1**2*Me**2 - lamF3e1x1**2*MXc**2 + lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3e1**2 - 2*MXc**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xc__tilde__,P.YF3Le1):'((lamF3L1x1**2*Me**2 - lamF3L1x1**2*MXc**2 + lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3Le1**2 - 2*MXc**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xs,P.YF3e1):'((lamF3e1x1**2*Me**2 - lamF3e1x1**2*MXs**2 + lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3e1**2 - 2*MXs**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xs,P.YF3Le1):'((lamF3L1x1**2*Me**2 - lamF3L1x1**2*MXs**2 + lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3Le1**2 - 2*MXs**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xv,P.YF3e1):'((lamF3e1x1**2*Me**2 + (lamF3e1x1**2*Me**4)/MXv**2 - 2*lamF3e1x1**2*MXv**2 + lamF3e1x1**2*MYF3e1**2 - (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXv**2 + (lamF3e1x1**2*MYF3e1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3e1**2 - 2*MXv**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xv,P.YF3Le1):'((lamF3L1x1**2*Me**2 + (lamF3L1x1**2*Me**4)/MXv**2 - 2*lamF3L1x1**2*MXv**2 + lamF3L1x1**2*MYF3Le1**2 - (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXv**2 + (lamF3L1x1**2*MYF3Le1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3Le1**2 - 2*MXv**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xw__tilde__,P.YF3e1):'((lamF3e1x1**2*Me**2 + (lamF3e1x1**2*Me**4)/MXw**2 - 2*lamF3e1x1**2*MXw**2 + lamF3e1x1**2*MYF3e1**2 - (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXw**2 + (lamF3e1x1**2*MYF3e1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3e1**2 - 2*MXw**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.Xw__tilde__,P.YF3Le1):'((lamF3L1x1**2*Me**2 + (lamF3L1x1**2*Me**4)/MXw**2 - 2*lamF3L1x1**2*MXw**2 + lamF3L1x1**2*MYF3Le1**2 - (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXw**2 + (lamF3L1x1**2*MYF3Le1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3Le1**2 - 2*MXw**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.YS3e1,P.Xd):'((lamS3e1x1**2*Me**2 + lamS3e1x1**2*MXd**2 - lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3e1**2 - 2*MXd**2*MYS3e1**2 + MYS3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.YS3e1,P.Xm):'((lamS3e1x1**2*Me**2 + lamS3e1x1**2*MXm**2 - lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3e1**2 - 2*MXm**2*MYS3e1**2 + MYS3e1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.YS3Le1,P.Xd):'((lamS3L1x1**2*Me**2 + lamS3L1x1**2*MXd**2 - lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3Le1**2 - 2*MXd**2*MYS3Le1**2 + MYS3Le1**4))/(32.*cmath.pi*abs(Me)**3)',
                                           (P.YS3Le1,P.Xm):'((lamS3L1x1**2*Me**2 + lamS3L1x1**2*MXm**2 - lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3Le1**2 - 2*MXm**2*MYS3Le1**2 + MYS3Le1**4))/(32.*cmath.pi*abs(Me)**3)'})

Decay_H = Decay(name = 'Decay_H',
                particle = P.H,
                partial_widths = {(P.b,P.b__tilde__):'((-12*MB**2*yb**2 + 3*MH**2*yb**2)*cmath.sqrt(-4*MB**2*MH**2 + MH**4))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.c,P.c__tilde__):'((-12*MC**2*yc**2 + 3*MH**2*yc**2)*cmath.sqrt(-4*MC**2*MH**2 + MH**4))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.d,P.d__tilde__):'((-12*MD**2*ydo**2 + 3*MH**2*ydo**2)*cmath.sqrt(-4*MD**2*MH**2 + MH**4))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.e__minus__,P.e__plus__):'((-4*Me**2*ye**2 + MH**2*ye**2)*cmath.sqrt(-4*Me**2*MH**2 + MH**4))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.mu__minus__,P.mu__plus__):'((MH**2*ym**2 - 4*MMU**2*ym**2)*cmath.sqrt(MH**4 - 4*MH**2*MMU**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.s,P.s__tilde__):'((3*MH**2*ys**2 - 12*MS**2*ys**2)*cmath.sqrt(MH**4 - 4*MH**2*MS**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.t,P.t__tilde__):'((3*MH**2*yt**2 - 12*MT**2*yt**2)*cmath.sqrt(MH**4 - 4*MH**2*MT**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((MH**2*ytau**2 - 4*MTA**2*ytau**2)*cmath.sqrt(MH**4 - 4*MH**2*MTA**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.u,P.u__tilde__):'((3*MH**2*yup**2 - 12*MU**2*yup**2)*cmath.sqrt(MH**4 - 4*MH**2*MU**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.W__minus__,P.W__plus__):'(((3*ee**4*vev**2)/(4.*sw**4) + (ee**4*MH**4*vev**2)/(16.*MW**4*sw**4) - (ee**4*MH**2*vev**2)/(4.*MW**2*sw**4))*cmath.sqrt(MH**4 - 4*MH**2*MW**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.Z,P.Z):'(((9*ee**4*vev**2)/2. + (3*ee**4*MH**4*vev**2)/(8.*MZ**4) - (3*ee**4*MH**2*vev**2)/(2.*MZ**2) + (3*cw**4*ee**4*vev**2)/(4.*sw**4) + (cw**4*ee**4*MH**4*vev**2)/(16.*MZ**4*sw**4) - (cw**4*ee**4*MH**2*vev**2)/(4.*MZ**2*sw**4) + (3*cw**2*ee**4*vev**2)/sw**2 + (cw**2*ee**4*MH**4*vev**2)/(4.*MZ**4*sw**2) - (cw**2*ee**4*MH**2*vev**2)/(MZ**2*sw**2) + (3*ee**4*sw**2*vev**2)/cw**2 + (ee**4*MH**4*sw**2*vev**2)/(4.*cw**2*MZ**4) - (ee**4*MH**2*sw**2*vev**2)/(cw**2*MZ**2) + (3*ee**4*sw**4*vev**2)/(4.*cw**4) + (ee**4*MH**4*sw**4*vev**2)/(16.*cw**4*MZ**4) - (ee**4*MH**2*sw**4*vev**2)/(4.*cw**4*MZ**2))*cmath.sqrt(MH**4 - 4*MH**2*MZ**2))/(32.*cmath.pi*abs(MH)**3)'})

Decay_mu__minus__ = Decay(name = 'Decay_mu__minus__',
                          particle = P.mu__minus__,
                          partial_widths = {(P.W__minus__,P.vm):'((MMU**2 - MW**2)*((ee**2*MMU**2)/(2.*sw**2) + (ee**2*MMU**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xc__tilde__,P.YF3e2):'((lamF3e2x2**2*MMU**2 - lamF3e2x2**2*MXc**2 + lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3e2**2 - 2*MXc**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xc__tilde__,P.YF3Le2):'((lamF3L2x2**2*MMU**2 - lamF3L2x2**2*MXc**2 + lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3Le2**2 - 2*MXc**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xs,P.YF3e2):'((lamF3e2x2**2*MMU**2 - lamF3e2x2**2*MXs**2 + lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3e2**2 - 2*MXs**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xs,P.YF3Le2):'((lamF3L2x2**2*MMU**2 - lamF3L2x2**2*MXs**2 + lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3Le2**2 - 2*MXs**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xv,P.YF3e2):'((lamF3e2x2**2*MMU**2 + (lamF3e2x2**2*MMU**4)/MXv**2 - 2*lamF3e2x2**2*MXv**2 + lamF3e2x2**2*MYF3e2**2 - (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXv**2 + (lamF3e2x2**2*MYF3e2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3e2**2 - 2*MXv**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xv,P.YF3Le2):'((lamF3L2x2**2*MMU**2 + (lamF3L2x2**2*MMU**4)/MXv**2 - 2*lamF3L2x2**2*MXv**2 + lamF3L2x2**2*MYF3Le2**2 - (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXv**2 + (lamF3L2x2**2*MYF3Le2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3Le2**2 - 2*MXv**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xw__tilde__,P.YF3e2):'((lamF3e2x2**2*MMU**2 + (lamF3e2x2**2*MMU**4)/MXw**2 - 2*lamF3e2x2**2*MXw**2 + lamF3e2x2**2*MYF3e2**2 - (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXw**2 + (lamF3e2x2**2*MYF3e2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3e2**2 - 2*MXw**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.Xw__tilde__,P.YF3Le2):'((lamF3L2x2**2*MMU**2 + (lamF3L2x2**2*MMU**4)/MXw**2 - 2*lamF3L2x2**2*MXw**2 + lamF3L2x2**2*MYF3Le2**2 - (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXw**2 + (lamF3L2x2**2*MYF3Le2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3Le2**2 - 2*MXw**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.YS3e2,P.Xd):'((lamS3e2x2**2*MMU**2 + lamS3e2x2**2*MXd**2 - lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3e2**2 - 2*MXd**2*MYS3e2**2 + MYS3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.YS3e2,P.Xm):'((lamS3e2x2**2*MMU**2 + lamS3e2x2**2*MXm**2 - lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3e2**2 - 2*MXm**2*MYS3e2**2 + MYS3e2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.YS3Le2,P.Xd):'((lamS3L2x2**2*MMU**2 + lamS3L2x2**2*MXd**2 - lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3Le2**2 - 2*MXd**2*MYS3Le2**2 + MYS3Le2**4))/(32.*cmath.pi*abs(MMU)**3)',
                                            (P.YS3Le2,P.Xm):'((lamS3L2x2**2*MMU**2 + lamS3L2x2**2*MXm**2 - lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3Le2**2 - 2*MXm**2*MYS3Le2**2 + MYS3Le2**4))/(32.*cmath.pi*abs(MMU)**3)'})

Decay_s = Decay(name = 'Decay_s',
                particle = P.s,
                partial_widths = {(P.W__minus__,P.c):'(((3*ee**2*MC**2)/(2.*sw**2) + (3*ee**2*MS**2)/(2.*sw**2) + (3*ee**2*MC**4)/(2.*MW**2*sw**2) - (3*ee**2*MC**2*MS**2)/(MW**2*sw**2) + (3*ee**2*MS**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MC**4 - 2*MC**2*MS**2 + MS**4 - 2*MC**2*MW**2 - 2*MS**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MS)**3)'})

Decay_t = Decay(name = 'Decay_t',
                particle = P.t,
                partial_widths = {(P.W__plus__,P.b):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MT)**3)'})

Decay_ta__minus__ = Decay(name = 'Decay_ta__minus__',
                          particle = P.ta__minus__,
                          partial_widths = {(P.W__minus__,P.vt):'((MTA**2 - MW**2)*((ee**2*MTA**2)/(2.*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xc__tilde__,P.YF3e3):'((lamF3e3x3**2*MTA**2 - lamF3e3x3**2*MXc**2 + lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3e3**2 - 2*MXc**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xc__tilde__,P.YF3Le3):'((lamF3L3x3**2*MTA**2 - lamF3L3x3**2*MXc**2 + lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3Le3**2 - 2*MXc**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xs,P.YF3e3):'((lamF3e3x3**2*MTA**2 - lamF3e3x3**2*MXs**2 + lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3e3**2 - 2*MXs**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xs,P.YF3Le3):'((lamF3L3x3**2*MTA**2 - lamF3L3x3**2*MXs**2 + lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3Le3**2 - 2*MXs**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xv,P.YF3e3):'((lamF3e3x3**2*MTA**2 + (lamF3e3x3**2*MTA**4)/MXv**2 - 2*lamF3e3x3**2*MXv**2 + lamF3e3x3**2*MYF3e3**2 - (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXv**2 + (lamF3e3x3**2*MYF3e3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3e3**2 - 2*MXv**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xv,P.YF3Le3):'((lamF3L3x3**2*MTA**2 + (lamF3L3x3**2*MTA**4)/MXv**2 - 2*lamF3L3x3**2*MXv**2 + lamF3L3x3**2*MYF3Le3**2 - (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXv**2 + (lamF3L3x3**2*MYF3Le3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3Le3**2 - 2*MXv**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xw__tilde__,P.YF3e3):'((lamF3e3x3**2*MTA**2 + (lamF3e3x3**2*MTA**4)/MXw**2 - 2*lamF3e3x3**2*MXw**2 + lamF3e3x3**2*MYF3e3**2 - (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXw**2 + (lamF3e3x3**2*MYF3e3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3e3**2 - 2*MXw**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.Xw__tilde__,P.YF3Le3):'((lamF3L3x3**2*MTA**2 + (lamF3L3x3**2*MTA**4)/MXw**2 - 2*lamF3L3x3**2*MXw**2 + lamF3L3x3**2*MYF3Le3**2 - (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXw**2 + (lamF3L3x3**2*MYF3Le3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3Le3**2 - 2*MXw**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.YS3e3,P.Xd):'((lamS3e3x3**2*MTA**2 + lamS3e3x3**2*MXd**2 - lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3e3**2 - 2*MXd**2*MYS3e3**2 + MYS3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.YS3e3,P.Xm):'((lamS3e3x3**2*MTA**2 + lamS3e3x3**2*MXm**2 - lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3e3**2 - 2*MXm**2*MYS3e3**2 + MYS3e3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.YS3Le3,P.Xd):'((lamS3L3x3**2*MTA**2 + lamS3L3x3**2*MXd**2 - lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3Le3**2 - 2*MXd**2*MYS3Le3**2 + MYS3Le3**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.YS3Le3,P.Xm):'((lamS3L3x3**2*MTA**2 + lamS3L3x3**2*MXm**2 - lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3Le3**2 - 2*MXm**2*MYS3Le3**2 + MYS3Le3**4))/(32.*cmath.pi*abs(MTA)**3)'})

Decay_u = Decay(name = 'Decay_u',
                particle = P.u,
                partial_widths = {(P.W__plus__,P.d):'(((3*ee**2*MD**2)/(2.*sw**2) + (3*ee**2*MU**2)/(2.*sw**2) + (3*ee**2*MD**4)/(2.*MW**2*sw**2) - (3*ee**2*MD**2*MU**2)/(MW**2*sw**2) + (3*ee**2*MU**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MD**4 - 2*MD**2*MU**2 + MU**4 - 2*MD**2*MW**2 - 2*MU**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MU)**3)'})

Decay_W__plus__ = Decay(name = 'Decay_W__plus__',
                        particle = P.W__plus__,
                        partial_widths = {(P.c,P.s__tilde__):'(((-3*ee**2*MC**2)/(2.*sw**2) - (3*ee**2*MS**2)/(2.*sw**2) - (3*ee**2*MC**4)/(2.*MW**2*sw**2) + (3*ee**2*MC**2*MS**2)/(MW**2*sw**2) - (3*ee**2*MS**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MC**4 - 2*MC**2*MS**2 + MS**4 - 2*MC**2*MW**2 - 2*MS**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.t,P.b__tilde__):'(((-3*ee**2*MB**2)/(2.*sw**2) - (3*ee**2*MT**2)/(2.*sw**2) - (3*ee**2*MB**4)/(2.*MW**2*sw**2) + (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) - (3*ee**2*MT**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.u,P.d__tilde__):'(((-3*ee**2*MD**2)/(2.*sw**2) - (3*ee**2*MU**2)/(2.*sw**2) - (3*ee**2*MD**4)/(2.*MW**2*sw**2) + (3*ee**2*MD**2*MU**2)/(MW**2*sw**2) - (3*ee**2*MU**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MD**4 - 2*MD**2*MU**2 + MU**4 - 2*MD**2*MW**2 - 2*MU**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.ve,P.e__plus__):'((-Me**2 + MW**2)*(-(ee**2*Me**2)/(2.*sw**2) - (ee**2*Me**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.vm,P.mu__plus__):'((-MMU**2 + MW**2)*(-(ee**2*MMU**2)/(2.*sw**2) - (ee**2*MMU**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.vt,P.ta__plus__):'((-MTA**2 + MW**2)*(-(ee**2*MTA**2)/(2.*sw**2) - (ee**2*MTA**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YF3Ln1,P.YF3Le1__tilde__):'(((2*ee**2*MW**2)/sw**2 - (ee**2*MYF3Le1**2)/sw**2 - (ee**2*MYF3Le1**4)/(MW**2*sw**2) + (6*ee**2*MYF3Le1*MYF3Ln1)/sw**2 - (ee**2*MYF3Ln1**2)/sw**2 + (2*ee**2*MYF3Le1**2*MYF3Ln1**2)/(MW**2*sw**2) - (ee**2*MYF3Ln1**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le1**2 + MYF3Le1**4 - 2*MW**2*MYF3Ln1**2 - 2*MYF3Le1**2*MYF3Ln1**2 + MYF3Ln1**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YF3Ln2,P.YF3Le2__tilde__):'(((2*ee**2*MW**2)/sw**2 - (ee**2*MYF3Le2**2)/sw**2 - (ee**2*MYF3Le2**4)/(MW**2*sw**2) + (6*ee**2*MYF3Le2*MYF3Ln2)/sw**2 - (ee**2*MYF3Ln2**2)/sw**2 + (2*ee**2*MYF3Le2**2*MYF3Ln2**2)/(MW**2*sw**2) - (ee**2*MYF3Ln2**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le2**2 + MYF3Le2**4 - 2*MW**2*MYF3Ln2**2 - 2*MYF3Le2**2*MYF3Ln2**2 + MYF3Ln2**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YF3Ln3,P.YF3Le3__tilde__):'(((2*ee**2*MW**2)/sw**2 - (ee**2*MYF3Le3**2)/sw**2 - (ee**2*MYF3Le3**4)/(MW**2*sw**2) + (6*ee**2*MYF3Le3*MYF3Ln3)/sw**2 - (ee**2*MYF3Ln3**2)/sw**2 + (2*ee**2*MYF3Le3**2*MYF3Ln3**2)/(MW**2*sw**2) - (ee**2*MYF3Ln3**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le3**2 + MYF3Le3**4 - 2*MW**2*MYF3Ln3**2 - 2*MYF3Le3**2*MYF3Ln3**2 + MYF3Ln3**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YS3Le1__tilde__,P.YS3Ln1):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le1**2)/sw**2 + (ee**2*MYS3Le1**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln1**2)/sw**2 - (ee**2*MYS3Le1**2*MYS3Ln1**2)/(MW**2*sw**2) + (ee**2*MYS3Ln1**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le1**2 + MYS3Le1**4 - 2*MW**2*MYS3Ln1**2 - 2*MYS3Le1**2*MYS3Ln1**2 + MYS3Ln1**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YS3Le2__tilde__,P.YS3Ln2):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le2**2)/sw**2 + (ee**2*MYS3Le2**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln2**2)/sw**2 - (ee**2*MYS3Le2**2*MYS3Ln2**2)/(MW**2*sw**2) + (ee**2*MYS3Ln2**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le2**2 + MYS3Le2**4 - 2*MW**2*MYS3Ln2**2 - 2*MYS3Le2**2*MYS3Ln2**2 + MYS3Ln2**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.YS3Le3__tilde__,P.YS3Ln3):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le3**2)/sw**2 + (ee**2*MYS3Le3**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln3**2)/sw**2 - (ee**2*MYS3Le3**2*MYS3Ln3**2)/(MW**2*sw**2) + (ee**2*MYS3Ln3**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le3**2 + MYS3Le3**4 - 2*MW**2*MYS3Ln3**2 - 2*MYS3Le3**2*MYS3Ln3**2 + MYS3Ln3**4))/(48.*cmath.pi*abs(MW)**3)'})

Decay_Xc = Decay(name = 'Decay_Xc',
                 particle = P.Xc,
                 partial_widths = {(P.YF3e1,P.e__plus__):'((-(lamF3e1x1**2*Me**2) + lamF3e1x1**2*MXc**2 - lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3e1**2 - 2*MXc**2*MYF3e1**2 + MYF3e1**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3e2,P.mu__plus__):'((-(lamF3e2x2**2*MMU**2) + lamF3e2x2**2*MXc**2 - lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3e2**2 - 2*MXc**2*MYF3e2**2 + MYF3e2**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3e3,P.ta__plus__):'((-(lamF3e3x3**2*MTA**2) + lamF3e3x3**2*MXc**2 - lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3e3**2 - 2*MXc**2*MYF3e3**2 + MYF3e3**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Le1,P.e__plus__):'((-(lamF3L1x1**2*Me**2) + lamF3L1x1**2*MXc**2 - lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3Le1**2 - 2*MXc**2*MYF3Le1**2 + MYF3Le1**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Le2,P.mu__plus__):'((-(lamF3L2x2**2*MMU**2) + lamF3L2x2**2*MXc**2 - lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3Le2**2 - 2*MXc**2*MYF3Le2**2 + MYF3Le2**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Le3,P.ta__plus__):'((-(lamF3L3x3**2*MTA**2) + lamF3L3x3**2*MXc**2 - lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3Le3**2 - 2*MXc**2*MYF3Le3**2 + MYF3Le3**4))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Ln1,P.ve__tilde__):'((MXc**2 - MYF3Ln1**2)*(lamF3L1x1**2*MXc**2 - lamF3L1x1**2*MYF3Ln1**2))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Ln2,P.vm__tilde__):'((MXc**2 - MYF3Ln2**2)*(lamF3L2x2**2*MXc**2 - lamF3L2x2**2*MYF3Ln2**2))/(16.*cmath.pi*abs(MXc)**3)',
                                   (P.YF3Ln3,P.vt__tilde__):'((MXc**2 - MYF3Ln3**2)*(lamF3L3x3**2*MXc**2 - lamF3L3x3**2*MYF3Ln3**2))/(16.*cmath.pi*abs(MXc)**3)'})

Decay_Xd = Decay(name = 'Decay_Xd',
                 particle = P.Xd,
                 partial_widths = {(P.YS3e1__tilde__,P.e__minus__):'((lamS3e1x1**2*Me**2 + lamS3e1x1**2*MXd**2 - lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3e1**2 - 2*MXd**2*MYS3e1**2 + MYS3e1**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3e2__tilde__,P.mu__minus__):'((lamS3e2x2**2*MMU**2 + lamS3e2x2**2*MXd**2 - lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3e2**2 - 2*MXd**2*MYS3e2**2 + MYS3e2**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3e3__tilde__,P.ta__minus__):'((lamS3e3x3**2*MTA**2 + lamS3e3x3**2*MXd**2 - lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3e3**2 - 2*MXd**2*MYS3e3**2 + MYS3e3**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Le1__tilde__,P.e__minus__):'((lamS3L1x1**2*Me**2 + lamS3L1x1**2*MXd**2 - lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3Le1**2 - 2*MXd**2*MYS3Le1**2 + MYS3Le1**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Le2__tilde__,P.mu__minus__):'((lamS3L2x2**2*MMU**2 + lamS3L2x2**2*MXd**2 - lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3Le2**2 - 2*MXd**2*MYS3Le2**2 + MYS3Le2**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Le3__tilde__,P.ta__minus__):'((lamS3L3x3**2*MTA**2 + lamS3L3x3**2*MXd**2 - lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3Le3**2 - 2*MXd**2*MYS3Le3**2 + MYS3Le3**4))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Ln1__tilde__,P.ve):'((MXd**2 - MYS3Ln1**2)*(lamS3L1x1**2*MXd**2 - lamS3L1x1**2*MYS3Ln1**2))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Ln2__tilde__,P.vm):'((MXd**2 - MYS3Ln2**2)*(lamS3L2x2**2*MXd**2 - lamS3L2x2**2*MYS3Ln2**2))/(32.*cmath.pi*abs(MXd)**3)',
                                   (P.YS3Ln3__tilde__,P.vt):'((MXd**2 - MYS3Ln3**2)*(lamS3L3x3**2*MXd**2 - lamS3L3x3**2*MYS3Ln3**2))/(32.*cmath.pi*abs(MXd)**3)'})

Decay_Xm = Decay(name = 'Decay_Xm',
                 particle = P.Xm,
                 partial_widths = {(P.YS3e1,P.e__plus__):'((lamS3e1x1**2*Me**2 + lamS3e1x1**2*MXm**2 - lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3e1**2 - 2*MXm**2*MYS3e1**2 + MYS3e1**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3e1__tilde__,P.e__minus__):'((lamS3e1x1**2*Me**2 + lamS3e1x1**2*MXm**2 - lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3e1**2 - 2*MXm**2*MYS3e1**2 + MYS3e1**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3e2,P.mu__plus__):'((lamS3e2x2**2*MMU**2 + lamS3e2x2**2*MXm**2 - lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3e2**2 - 2*MXm**2*MYS3e2**2 + MYS3e2**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3e2__tilde__,P.mu__minus__):'((lamS3e2x2**2*MMU**2 + lamS3e2x2**2*MXm**2 - lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3e2**2 - 2*MXm**2*MYS3e2**2 + MYS3e2**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3e3,P.ta__plus__):'((lamS3e3x3**2*MTA**2 + lamS3e3x3**2*MXm**2 - lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3e3**2 - 2*MXm**2*MYS3e3**2 + MYS3e3**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3e3__tilde__,P.ta__minus__):'((lamS3e3x3**2*MTA**2 + lamS3e3x3**2*MXm**2 - lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3e3**2 - 2*MXm**2*MYS3e3**2 + MYS3e3**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le1,P.e__plus__):'((lamS3L1x1**2*Me**2 + lamS3L1x1**2*MXm**2 - lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3Le1**2 - 2*MXm**2*MYS3Le1**2 + MYS3Le1**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le1__tilde__,P.e__minus__):'((lamS3L1x1**2*Me**2 + lamS3L1x1**2*MXm**2 - lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3Le1**2 - 2*MXm**2*MYS3Le1**2 + MYS3Le1**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le2,P.mu__plus__):'((lamS3L2x2**2*MMU**2 + lamS3L2x2**2*MXm**2 - lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3Le2**2 - 2*MXm**2*MYS3Le2**2 + MYS3Le2**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le2__tilde__,P.mu__minus__):'((lamS3L2x2**2*MMU**2 + lamS3L2x2**2*MXm**2 - lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3Le2**2 - 2*MXm**2*MYS3Le2**2 + MYS3Le2**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le3,P.ta__plus__):'((lamS3L3x3**2*MTA**2 + lamS3L3x3**2*MXm**2 - lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3Le3**2 - 2*MXm**2*MYS3Le3**2 + MYS3Le3**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Le3__tilde__,P.ta__minus__):'((lamS3L3x3**2*MTA**2 + lamS3L3x3**2*MXm**2 - lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3Le3**2 - 2*MXm**2*MYS3Le3**2 + MYS3Le3**4))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln1,P.ve__tilde__):'((MXm**2 - MYS3Ln1**2)*(lamS3L1x1**2*MXm**2 - lamS3L1x1**2*MYS3Ln1**2))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln1__tilde__,P.ve):'((MXm**2 - MYS3Ln1**2)*(lamS3L1x1**2*MXm**2 - lamS3L1x1**2*MYS3Ln1**2))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln2,P.vm__tilde__):'((MXm**2 - MYS3Ln2**2)*(lamS3L2x2**2*MXm**2 - lamS3L2x2**2*MYS3Ln2**2))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln2__tilde__,P.vm):'((MXm**2 - MYS3Ln2**2)*(lamS3L2x2**2*MXm**2 - lamS3L2x2**2*MYS3Ln2**2))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln3,P.vt__tilde__):'((MXm**2 - MYS3Ln3**2)*(lamS3L3x3**2*MXm**2 - lamS3L3x3**2*MYS3Ln3**2))/(32.*cmath.pi*abs(MXm)**3)',
                                   (P.YS3Ln3__tilde__,P.vt):'((MXm**2 - MYS3Ln3**2)*(lamS3L3x3**2*MXm**2 - lamS3L3x3**2*MYS3Ln3**2))/(32.*cmath.pi*abs(MXm)**3)'})

Decay_Xs = Decay(name = 'Decay_Xs',
                 particle = P.Xs,
                 partial_widths = {(P.e__minus__,P.YF3e1__tilde__):'((-(lamF3e1x1**2*Me**2) + lamF3e1x1**2*MXs**2 - lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3e1**2 - 2*MXs**2*MYF3e1**2 + MYF3e1**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.e__minus__,P.YF3Le1__tilde__):'((-(lamF3L1x1**2*Me**2) + lamF3L1x1**2*MXs**2 - lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3Le1**2 - 2*MXs**2*MYF3Le1**2 + MYF3Le1**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.mu__minus__,P.YF3e2__tilde__):'((-(lamF3e2x2**2*MMU**2) + lamF3e2x2**2*MXs**2 - lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3e2**2 - 2*MXs**2*MYF3e2**2 + MYF3e2**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.mu__minus__,P.YF3Le2__tilde__):'((-(lamF3L2x2**2*MMU**2) + lamF3L2x2**2*MXs**2 - lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3Le2**2 - 2*MXs**2*MYF3Le2**2 + MYF3Le2**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.ta__minus__,P.YF3e3__tilde__):'((-(lamF3e3x3**2*MTA**2) + lamF3e3x3**2*MXs**2 - lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3e3**2 - 2*MXs**2*MYF3e3**2 + MYF3e3**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.ta__minus__,P.YF3Le3__tilde__):'((-(lamF3L3x3**2*MTA**2) + lamF3L3x3**2*MXs**2 - lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3Le3**2 - 2*MXs**2*MYF3Le3**2 + MYF3Le3**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.ve,P.YF3Ln1__tilde__):'((MXs**2 - MYF3Ln1**2)*(lamF3L1x1**2*MXs**2 - lamF3L1x1**2*MYF3Ln1**2))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.vm,P.YF3Ln2__tilde__):'((MXs**2 - MYF3Ln2**2)*(lamF3L2x2**2*MXs**2 - lamF3L2x2**2*MYF3Ln2**2))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.vt,P.YF3Ln3__tilde__):'((MXs**2 - MYF3Ln3**2)*(lamF3L3x3**2*MXs**2 - lamF3L3x3**2*MYF3Ln3**2))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3e1,P.e__plus__):'((-(lamF3e1x1**2*Me**2) + lamF3e1x1**2*MXs**2 - lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3e1**2 - 2*MXs**2*MYF3e1**2 + MYF3e1**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3e2,P.mu__plus__):'((-(lamF3e2x2**2*MMU**2) + lamF3e2x2**2*MXs**2 - lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3e2**2 - 2*MXs**2*MYF3e2**2 + MYF3e2**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3e3,P.ta__plus__):'((-(lamF3e3x3**2*MTA**2) + lamF3e3x3**2*MXs**2 - lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3e3**2 - 2*MXs**2*MYF3e3**2 + MYF3e3**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Le1,P.e__plus__):'((-(lamF3L1x1**2*Me**2) + lamF3L1x1**2*MXs**2 - lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3Le1**2 - 2*MXs**2*MYF3Le1**2 + MYF3Le1**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Le2,P.mu__plus__):'((-(lamF3L2x2**2*MMU**2) + lamF3L2x2**2*MXs**2 - lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3Le2**2 - 2*MXs**2*MYF3Le2**2 + MYF3Le2**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Le3,P.ta__plus__):'((-(lamF3L3x3**2*MTA**2) + lamF3L3x3**2*MXs**2 - lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3Le3**2 - 2*MXs**2*MYF3Le3**2 + MYF3Le3**4))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Ln1,P.ve__tilde__):'((MXs**2 - MYF3Ln1**2)*(lamF3L1x1**2*MXs**2 - lamF3L1x1**2*MYF3Ln1**2))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Ln2,P.vm__tilde__):'((MXs**2 - MYF3Ln2**2)*(lamF3L2x2**2*MXs**2 - lamF3L2x2**2*MYF3Ln2**2))/(16.*cmath.pi*abs(MXs)**3)',
                                   (P.YF3Ln3,P.vt__tilde__):'((MXs**2 - MYF3Ln3**2)*(lamF3L3x3**2*MXs**2 - lamF3L3x3**2*MYF3Ln3**2))/(16.*cmath.pi*abs(MXs)**3)'})

Decay_Xv = Decay(name = 'Decay_Xv',
                 particle = P.Xv,
                 partial_widths = {(P.e__minus__,P.YF3e1__tilde__):'((-(lamF3e1x1**2*Me**2) - (lamF3e1x1**2*Me**4)/MXv**2 + 2*lamF3e1x1**2*MXv**2 - lamF3e1x1**2*MYF3e1**2 + (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXv**2 - (lamF3e1x1**2*MYF3e1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3e1**2 - 2*MXv**2*MYF3e1**2 + MYF3e1**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.e__minus__,P.YF3Le1__tilde__):'((-(lamF3L1x1**2*Me**2) - (lamF3L1x1**2*Me**4)/MXv**2 + 2*lamF3L1x1**2*MXv**2 - lamF3L1x1**2*MYF3Le1**2 + (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXv**2 - (lamF3L1x1**2*MYF3Le1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3Le1**2 - 2*MXv**2*MYF3Le1**2 + MYF3Le1**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.mu__minus__,P.YF3e2__tilde__):'((-(lamF3e2x2**2*MMU**2) - (lamF3e2x2**2*MMU**4)/MXv**2 + 2*lamF3e2x2**2*MXv**2 - lamF3e2x2**2*MYF3e2**2 + (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXv**2 - (lamF3e2x2**2*MYF3e2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3e2**2 - 2*MXv**2*MYF3e2**2 + MYF3e2**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.mu__minus__,P.YF3Le2__tilde__):'((-(lamF3L2x2**2*MMU**2) - (lamF3L2x2**2*MMU**4)/MXv**2 + 2*lamF3L2x2**2*MXv**2 - lamF3L2x2**2*MYF3Le2**2 + (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXv**2 - (lamF3L2x2**2*MYF3Le2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3Le2**2 - 2*MXv**2*MYF3Le2**2 + MYF3Le2**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.ta__minus__,P.YF3e3__tilde__):'((-(lamF3e3x3**2*MTA**2) - (lamF3e3x3**2*MTA**4)/MXv**2 + 2*lamF3e3x3**2*MXv**2 - lamF3e3x3**2*MYF3e3**2 + (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXv**2 - (lamF3e3x3**2*MYF3e3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3e3**2 - 2*MXv**2*MYF3e3**2 + MYF3e3**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.ta__minus__,P.YF3Le3__tilde__):'((-(lamF3L3x3**2*MTA**2) - (lamF3L3x3**2*MTA**4)/MXv**2 + 2*lamF3L3x3**2*MXv**2 - lamF3L3x3**2*MYF3Le3**2 + (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXv**2 - (lamF3L3x3**2*MYF3Le3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3Le3**2 - 2*MXv**2*MYF3Le3**2 + MYF3Le3**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.ve,P.YF3Ln1__tilde__):'((MXv**2 - MYF3Ln1**2)*(2*lamF3L1x1**2*MXv**2 - lamF3L1x1**2*MYF3Ln1**2 - (lamF3L1x1**2*MYF3Ln1**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.vm,P.YF3Ln2__tilde__):'((MXv**2 - MYF3Ln2**2)*(2*lamF3L2x2**2*MXv**2 - lamF3L2x2**2*MYF3Ln2**2 - (lamF3L2x2**2*MYF3Ln2**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.vt,P.YF3Ln3__tilde__):'((MXv**2 - MYF3Ln3**2)*(2*lamF3L3x3**2*MXv**2 - lamF3L3x3**2*MYF3Ln3**2 - (lamF3L3x3**2*MYF3Ln3**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3e1,P.e__plus__):'((-(lamF3e1x1**2*Me**2) - (lamF3e1x1**2*Me**4)/MXv**2 + 2*lamF3e1x1**2*MXv**2 - lamF3e1x1**2*MYF3e1**2 + (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXv**2 - (lamF3e1x1**2*MYF3e1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3e1**2 - 2*MXv**2*MYF3e1**2 + MYF3e1**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3e2,P.mu__plus__):'((-(lamF3e2x2**2*MMU**2) - (lamF3e2x2**2*MMU**4)/MXv**2 + 2*lamF3e2x2**2*MXv**2 - lamF3e2x2**2*MYF3e2**2 + (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXv**2 - (lamF3e2x2**2*MYF3e2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3e2**2 - 2*MXv**2*MYF3e2**2 + MYF3e2**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3e3,P.ta__plus__):'((-(lamF3e3x3**2*MTA**2) - (lamF3e3x3**2*MTA**4)/MXv**2 + 2*lamF3e3x3**2*MXv**2 - lamF3e3x3**2*MYF3e3**2 + (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXv**2 - (lamF3e3x3**2*MYF3e3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3e3**2 - 2*MXv**2*MYF3e3**2 + MYF3e3**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Le1,P.e__plus__):'((-(lamF3L1x1**2*Me**2) - (lamF3L1x1**2*Me**4)/MXv**2 + 2*lamF3L1x1**2*MXv**2 - lamF3L1x1**2*MYF3Le1**2 + (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXv**2 - (lamF3L1x1**2*MYF3Le1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3Le1**2 - 2*MXv**2*MYF3Le1**2 + MYF3Le1**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Le2,P.mu__plus__):'((-(lamF3L2x2**2*MMU**2) - (lamF3L2x2**2*MMU**4)/MXv**2 + 2*lamF3L2x2**2*MXv**2 - lamF3L2x2**2*MYF3Le2**2 + (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXv**2 - (lamF3L2x2**2*MYF3Le2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3Le2**2 - 2*MXv**2*MYF3Le2**2 + MYF3Le2**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Le3,P.ta__plus__):'((-(lamF3L3x3**2*MTA**2) - (lamF3L3x3**2*MTA**4)/MXv**2 + 2*lamF3L3x3**2*MXv**2 - lamF3L3x3**2*MYF3Le3**2 + (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXv**2 - (lamF3L3x3**2*MYF3Le3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3Le3**2 - 2*MXv**2*MYF3Le3**2 + MYF3Le3**4))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Ln1,P.ve__tilde__):'((MXv**2 - MYF3Ln1**2)*(2*lamF3L1x1**2*MXv**2 - lamF3L1x1**2*MYF3Ln1**2 - (lamF3L1x1**2*MYF3Ln1**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Ln2,P.vm__tilde__):'((MXv**2 - MYF3Ln2**2)*(2*lamF3L2x2**2*MXv**2 - lamF3L2x2**2*MYF3Ln2**2 - (lamF3L2x2**2*MYF3Ln2**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)',
                                   (P.YF3Ln3,P.vt__tilde__):'((MXv**2 - MYF3Ln3**2)*(2*lamF3L3x3**2*MXv**2 - lamF3L3x3**2*MYF3Ln3**2 - (lamF3L3x3**2*MYF3Ln3**4)/MXv**2))/(48.*cmath.pi*abs(MXv)**3)'})

Decay_Xw = Decay(name = 'Decay_Xw',
                 particle = P.Xw,
                 partial_widths = {(P.YF3e1,P.e__plus__):'((-(lamF3e1x1**2*Me**2) - (lamF3e1x1**2*Me**4)/MXw**2 + 2*lamF3e1x1**2*MXw**2 - lamF3e1x1**2*MYF3e1**2 + (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXw**2 - (lamF3e1x1**2*MYF3e1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3e1**2 - 2*MXw**2*MYF3e1**2 + MYF3e1**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3e2,P.mu__plus__):'((-(lamF3e2x2**2*MMU**2) - (lamF3e2x2**2*MMU**4)/MXw**2 + 2*lamF3e2x2**2*MXw**2 - lamF3e2x2**2*MYF3e2**2 + (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXw**2 - (lamF3e2x2**2*MYF3e2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3e2**2 - 2*MXw**2*MYF3e2**2 + MYF3e2**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3e3,P.ta__plus__):'((-(lamF3e3x3**2*MTA**2) - (lamF3e3x3**2*MTA**4)/MXw**2 + 2*lamF3e3x3**2*MXw**2 - lamF3e3x3**2*MYF3e3**2 + (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXw**2 - (lamF3e3x3**2*MYF3e3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3e3**2 - 2*MXw**2*MYF3e3**2 + MYF3e3**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Le1,P.e__plus__):'((-(lamF3L1x1**2*Me**2) - (lamF3L1x1**2*Me**4)/MXw**2 + 2*lamF3L1x1**2*MXw**2 - lamF3L1x1**2*MYF3Le1**2 + (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXw**2 - (lamF3L1x1**2*MYF3Le1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3Le1**2 - 2*MXw**2*MYF3Le1**2 + MYF3Le1**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Le2,P.mu__plus__):'((-(lamF3L2x2**2*MMU**2) - (lamF3L2x2**2*MMU**4)/MXw**2 + 2*lamF3L2x2**2*MXw**2 - lamF3L2x2**2*MYF3Le2**2 + (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXw**2 - (lamF3L2x2**2*MYF3Le2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3Le2**2 - 2*MXw**2*MYF3Le2**2 + MYF3Le2**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Le3,P.ta__plus__):'((-(lamF3L3x3**2*MTA**2) - (lamF3L3x3**2*MTA**4)/MXw**2 + 2*lamF3L3x3**2*MXw**2 - lamF3L3x3**2*MYF3Le3**2 + (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXw**2 - (lamF3L3x3**2*MYF3Le3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3Le3**2 - 2*MXw**2*MYF3Le3**2 + MYF3Le3**4))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Ln1,P.ve__tilde__):'((MXw**2 - MYF3Ln1**2)*(2*lamF3L1x1**2*MXw**2 - lamF3L1x1**2*MYF3Ln1**2 - (lamF3L1x1**2*MYF3Ln1**4)/MXw**2))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Ln2,P.vm__tilde__):'((MXw**2 - MYF3Ln2**2)*(2*lamF3L2x2**2*MXw**2 - lamF3L2x2**2*MYF3Ln2**2 - (lamF3L2x2**2*MYF3Ln2**4)/MXw**2))/(48.*cmath.pi*abs(MXw)**3)',
                                   (P.YF3Ln3,P.vt__tilde__):'((MXw**2 - MYF3Ln3**2)*(2*lamF3L3x3**2*MXw**2 - lamF3L3x3**2*MYF3Ln3**2 - (lamF3L3x3**2*MYF3Ln3**4)/MXw**2))/(48.*cmath.pi*abs(MXw)**3)'})

Decay_YF3e1 = Decay(name = 'Decay_YF3e1',
                    particle = P.YF3e1,
                    partial_widths = {(P.Xc,P.e__minus__):'((lamF3e1x1**2*Me**2 - lamF3e1x1**2*MXc**2 + lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3e1**2 - 2*MXc**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(MYF3e1)**3)',
                                      (P.Xs,P.e__minus__):'((lamF3e1x1**2*Me**2 - lamF3e1x1**2*MXs**2 + lamF3e1x1**2*MYF3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3e1**2 - 2*MXs**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(MYF3e1)**3)',
                                      (P.Xv,P.e__minus__):'((lamF3e1x1**2*Me**2 + (lamF3e1x1**2*Me**4)/MXv**2 - 2*lamF3e1x1**2*MXv**2 + lamF3e1x1**2*MYF3e1**2 - (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXv**2 + (lamF3e1x1**2*MYF3e1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3e1**2 - 2*MXv**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(MYF3e1)**3)',
                                      (P.Xw,P.e__minus__):'((lamF3e1x1**2*Me**2 + (lamF3e1x1**2*Me**4)/MXw**2 - 2*lamF3e1x1**2*MXw**2 + lamF3e1x1**2*MYF3e1**2 - (2*lamF3e1x1**2*Me**2*MYF3e1**2)/MXw**2 + (lamF3e1x1**2*MYF3e1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3e1**2 - 2*MXw**2*MYF3e1**2 + MYF3e1**4))/(32.*cmath.pi*abs(MYF3e1)**3)'})

Decay_YF3e2 = Decay(name = 'Decay_YF3e2',
                    particle = P.YF3e2,
                    partial_widths = {(P.Xc,P.mu__minus__):'((lamF3e2x2**2*MMU**2 - lamF3e2x2**2*MXc**2 + lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3e2**2 - 2*MXc**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MYF3e2)**3)',
                                      (P.Xs,P.mu__minus__):'((lamF3e2x2**2*MMU**2 - lamF3e2x2**2*MXs**2 + lamF3e2x2**2*MYF3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3e2**2 - 2*MXs**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MYF3e2)**3)',
                                      (P.Xv,P.mu__minus__):'((lamF3e2x2**2*MMU**2 + (lamF3e2x2**2*MMU**4)/MXv**2 - 2*lamF3e2x2**2*MXv**2 + lamF3e2x2**2*MYF3e2**2 - (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXv**2 + (lamF3e2x2**2*MYF3e2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3e2**2 - 2*MXv**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MYF3e2)**3)',
                                      (P.Xw,P.mu__minus__):'((lamF3e2x2**2*MMU**2 + (lamF3e2x2**2*MMU**4)/MXw**2 - 2*lamF3e2x2**2*MXw**2 + lamF3e2x2**2*MYF3e2**2 - (2*lamF3e2x2**2*MMU**2*MYF3e2**2)/MXw**2 + (lamF3e2x2**2*MYF3e2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3e2**2 - 2*MXw**2*MYF3e2**2 + MYF3e2**4))/(32.*cmath.pi*abs(MYF3e2)**3)'})

Decay_YF3e3 = Decay(name = 'Decay_YF3e3',
                    particle = P.YF3e3,
                    partial_widths = {(P.Xc,P.ta__minus__):'((lamF3e3x3**2*MTA**2 - lamF3e3x3**2*MXc**2 + lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3e3**2 - 2*MXc**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MYF3e3)**3)',
                                      (P.Xs,P.ta__minus__):'((lamF3e3x3**2*MTA**2 - lamF3e3x3**2*MXs**2 + lamF3e3x3**2*MYF3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3e3**2 - 2*MXs**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MYF3e3)**3)',
                                      (P.Xv,P.ta__minus__):'((lamF3e3x3**2*MTA**2 + (lamF3e3x3**2*MTA**4)/MXv**2 - 2*lamF3e3x3**2*MXv**2 + lamF3e3x3**2*MYF3e3**2 - (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXv**2 + (lamF3e3x3**2*MYF3e3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3e3**2 - 2*MXv**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MYF3e3)**3)',
                                      (P.Xw,P.ta__minus__):'((lamF3e3x3**2*MTA**2 + (lamF3e3x3**2*MTA**4)/MXw**2 - 2*lamF3e3x3**2*MXw**2 + lamF3e3x3**2*MYF3e3**2 - (2*lamF3e3x3**2*MTA**2*MYF3e3**2)/MXw**2 + (lamF3e3x3**2*MYF3e3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3e3**2 - 2*MXw**2*MYF3e3**2 + MYF3e3**4))/(32.*cmath.pi*abs(MYF3e3)**3)'})

Decay_YF3Le1 = Decay(name = 'Decay_YF3Le1',
                     particle = P.YF3Le1,
                     partial_widths = {(P.W__minus__,P.YF3Ln1):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le1**2)/sw**2 + (ee**2*MYF3Le1**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le1*MYF3Ln1)/sw**2 + (ee**2*MYF3Ln1**2)/sw**2 - (2*ee**2*MYF3Le1**2*MYF3Ln1**2)/(MW**2*sw**2) + (ee**2*MYF3Ln1**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le1**2 + MYF3Le1**4 - 2*MW**2*MYF3Ln1**2 - 2*MYF3Le1**2*MYF3Ln1**2 + MYF3Ln1**4))/(32.*cmath.pi*abs(MYF3Le1)**3)',
                                       (P.Xc,P.e__minus__):'((lamF3L1x1**2*Me**2 - lamF3L1x1**2*MXc**2 + lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXc**2 + MXc**4 - 2*Me**2*MYF3Le1**2 - 2*MXc**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(MYF3Le1)**3)',
                                       (P.Xs,P.e__minus__):'((lamF3L1x1**2*Me**2 - lamF3L1x1**2*MXs**2 + lamF3L1x1**2*MYF3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXs**2 + MXs**4 - 2*Me**2*MYF3Le1**2 - 2*MXs**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(MYF3Le1)**3)',
                                       (P.Xv,P.e__minus__):'((lamF3L1x1**2*Me**2 + (lamF3L1x1**2*Me**4)/MXv**2 - 2*lamF3L1x1**2*MXv**2 + lamF3L1x1**2*MYF3Le1**2 - (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXv**2 + (lamF3L1x1**2*MYF3Le1**4)/MXv**2)*cmath.sqrt(Me**4 - 2*Me**2*MXv**2 + MXv**4 - 2*Me**2*MYF3Le1**2 - 2*MXv**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(MYF3Le1)**3)',
                                       (P.Xw,P.e__minus__):'((lamF3L1x1**2*Me**2 + (lamF3L1x1**2*Me**4)/MXw**2 - 2*lamF3L1x1**2*MXw**2 + lamF3L1x1**2*MYF3Le1**2 - (2*lamF3L1x1**2*Me**2*MYF3Le1**2)/MXw**2 + (lamF3L1x1**2*MYF3Le1**4)/MXw**2)*cmath.sqrt(Me**4 - 2*Me**2*MXw**2 + MXw**4 - 2*Me**2*MYF3Le1**2 - 2*MXw**2*MYF3Le1**2 + MYF3Le1**4))/(32.*cmath.pi*abs(MYF3Le1)**3)'})

Decay_YF3Le2 = Decay(name = 'Decay_YF3Le2',
                     particle = P.YF3Le2,
                     partial_widths = {(P.W__minus__,P.YF3Ln2):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le2**2)/sw**2 + (ee**2*MYF3Le2**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le2*MYF3Ln2)/sw**2 + (ee**2*MYF3Ln2**2)/sw**2 - (2*ee**2*MYF3Le2**2*MYF3Ln2**2)/(MW**2*sw**2) + (ee**2*MYF3Ln2**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le2**2 + MYF3Le2**4 - 2*MW**2*MYF3Ln2**2 - 2*MYF3Le2**2*MYF3Ln2**2 + MYF3Ln2**4))/(32.*cmath.pi*abs(MYF3Le2)**3)',
                                       (P.Xc,P.mu__minus__):'((lamF3L2x2**2*MMU**2 - lamF3L2x2**2*MXc**2 + lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXc**2 + MXc**4 - 2*MMU**2*MYF3Le2**2 - 2*MXc**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MYF3Le2)**3)',
                                       (P.Xs,P.mu__minus__):'((lamF3L2x2**2*MMU**2 - lamF3L2x2**2*MXs**2 + lamF3L2x2**2*MYF3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXs**2 + MXs**4 - 2*MMU**2*MYF3Le2**2 - 2*MXs**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MYF3Le2)**3)',
                                       (P.Xv,P.mu__minus__):'((lamF3L2x2**2*MMU**2 + (lamF3L2x2**2*MMU**4)/MXv**2 - 2*lamF3L2x2**2*MXv**2 + lamF3L2x2**2*MYF3Le2**2 - (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXv**2 + (lamF3L2x2**2*MYF3Le2**4)/MXv**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXv**2 + MXv**4 - 2*MMU**2*MYF3Le2**2 - 2*MXv**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MYF3Le2)**3)',
                                       (P.Xw,P.mu__minus__):'((lamF3L2x2**2*MMU**2 + (lamF3L2x2**2*MMU**4)/MXw**2 - 2*lamF3L2x2**2*MXw**2 + lamF3L2x2**2*MYF3Le2**2 - (2*lamF3L2x2**2*MMU**2*MYF3Le2**2)/MXw**2 + (lamF3L2x2**2*MYF3Le2**4)/MXw**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXw**2 + MXw**4 - 2*MMU**2*MYF3Le2**2 - 2*MXw**2*MYF3Le2**2 + MYF3Le2**4))/(32.*cmath.pi*abs(MYF3Le2)**3)'})

Decay_YF3Le3 = Decay(name = 'Decay_YF3Le3',
                     particle = P.YF3Le3,
                     partial_widths = {(P.W__minus__,P.YF3Ln3):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le3**2)/sw**2 + (ee**2*MYF3Le3**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le3*MYF3Ln3)/sw**2 + (ee**2*MYF3Ln3**2)/sw**2 - (2*ee**2*MYF3Le3**2*MYF3Ln3**2)/(MW**2*sw**2) + (ee**2*MYF3Ln3**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le3**2 + MYF3Le3**4 - 2*MW**2*MYF3Ln3**2 - 2*MYF3Le3**2*MYF3Ln3**2 + MYF3Ln3**4))/(32.*cmath.pi*abs(MYF3Le3)**3)',
                                       (P.Xc,P.ta__minus__):'((lamF3L3x3**2*MTA**2 - lamF3L3x3**2*MXc**2 + lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXc**2 + MXc**4 - 2*MTA**2*MYF3Le3**2 - 2*MXc**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MYF3Le3)**3)',
                                       (P.Xs,P.ta__minus__):'((lamF3L3x3**2*MTA**2 - lamF3L3x3**2*MXs**2 + lamF3L3x3**2*MYF3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXs**2 + MXs**4 - 2*MTA**2*MYF3Le3**2 - 2*MXs**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MYF3Le3)**3)',
                                       (P.Xv,P.ta__minus__):'((lamF3L3x3**2*MTA**2 + (lamF3L3x3**2*MTA**4)/MXv**2 - 2*lamF3L3x3**2*MXv**2 + lamF3L3x3**2*MYF3Le3**2 - (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXv**2 + (lamF3L3x3**2*MYF3Le3**4)/MXv**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXv**2 + MXv**4 - 2*MTA**2*MYF3Le3**2 - 2*MXv**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MYF3Le3)**3)',
                                       (P.Xw,P.ta__minus__):'((lamF3L3x3**2*MTA**2 + (lamF3L3x3**2*MTA**4)/MXw**2 - 2*lamF3L3x3**2*MXw**2 + lamF3L3x3**2*MYF3Le3**2 - (2*lamF3L3x3**2*MTA**2*MYF3Le3**2)/MXw**2 + (lamF3L3x3**2*MYF3Le3**4)/MXw**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXw**2 + MXw**4 - 2*MTA**2*MYF3Le3**2 - 2*MXw**2*MYF3Le3**2 + MYF3Le3**4))/(32.*cmath.pi*abs(MYF3Le3)**3)'})

Decay_YF3Ln1 = Decay(name = 'Decay_YF3Ln1',
                     particle = P.YF3Ln1,
                     partial_widths = {(P.W__plus__,P.YF3Le1):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le1**2)/sw**2 + (ee**2*MYF3Le1**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le1*MYF3Ln1)/sw**2 + (ee**2*MYF3Ln1**2)/sw**2 - (2*ee**2*MYF3Le1**2*MYF3Ln1**2)/(MW**2*sw**2) + (ee**2*MYF3Ln1**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le1**2 + MYF3Le1**4 - 2*MW**2*MYF3Ln1**2 - 2*MYF3Le1**2*MYF3Ln1**2 + MYF3Ln1**4))/(32.*cmath.pi*abs(MYF3Ln1)**3)',
                                       (P.Xc,P.ve):'((-MXc**2 + MYF3Ln1**2)*(-(lamF3L1x1**2*MXc**2) + lamF3L1x1**2*MYF3Ln1**2))/(32.*cmath.pi*abs(MYF3Ln1)**3)',
                                       (P.Xs,P.ve):'((-MXs**2 + MYF3Ln1**2)*(-(lamF3L1x1**2*MXs**2) + lamF3L1x1**2*MYF3Ln1**2))/(32.*cmath.pi*abs(MYF3Ln1)**3)',
                                       (P.Xv,P.ve):'((-MXv**2 + MYF3Ln1**2)*(-2*lamF3L1x1**2*MXv**2 + lamF3L1x1**2*MYF3Ln1**2 + (lamF3L1x1**2*MYF3Ln1**4)/MXv**2))/(32.*cmath.pi*abs(MYF3Ln1)**3)',
                                       (P.Xw,P.ve):'((-MXw**2 + MYF3Ln1**2)*(-2*lamF3L1x1**2*MXw**2 + lamF3L1x1**2*MYF3Ln1**2 + (lamF3L1x1**2*MYF3Ln1**4)/MXw**2))/(32.*cmath.pi*abs(MYF3Ln1)**3)'})

Decay_YF3Ln2 = Decay(name = 'Decay_YF3Ln2',
                     particle = P.YF3Ln2,
                     partial_widths = {(P.W__plus__,P.YF3Le2):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le2**2)/sw**2 + (ee**2*MYF3Le2**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le2*MYF3Ln2)/sw**2 + (ee**2*MYF3Ln2**2)/sw**2 - (2*ee**2*MYF3Le2**2*MYF3Ln2**2)/(MW**2*sw**2) + (ee**2*MYF3Ln2**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le2**2 + MYF3Le2**4 - 2*MW**2*MYF3Ln2**2 - 2*MYF3Le2**2*MYF3Ln2**2 + MYF3Ln2**4))/(32.*cmath.pi*abs(MYF3Ln2)**3)',
                                       (P.Xc,P.vm):'((-MXc**2 + MYF3Ln2**2)*(-(lamF3L2x2**2*MXc**2) + lamF3L2x2**2*MYF3Ln2**2))/(32.*cmath.pi*abs(MYF3Ln2)**3)',
                                       (P.Xs,P.vm):'((-MXs**2 + MYF3Ln2**2)*(-(lamF3L2x2**2*MXs**2) + lamF3L2x2**2*MYF3Ln2**2))/(32.*cmath.pi*abs(MYF3Ln2)**3)',
                                       (P.Xv,P.vm):'((-MXv**2 + MYF3Ln2**2)*(-2*lamF3L2x2**2*MXv**2 + lamF3L2x2**2*MYF3Ln2**2 + (lamF3L2x2**2*MYF3Ln2**4)/MXv**2))/(32.*cmath.pi*abs(MYF3Ln2)**3)',
                                       (P.Xw,P.vm):'((-MXw**2 + MYF3Ln2**2)*(-2*lamF3L2x2**2*MXw**2 + lamF3L2x2**2*MYF3Ln2**2 + (lamF3L2x2**2*MYF3Ln2**4)/MXw**2))/(32.*cmath.pi*abs(MYF3Ln2)**3)'})

Decay_YF3Ln3 = Decay(name = 'Decay_YF3Ln3',
                     particle = P.YF3Ln3,
                     partial_widths = {(P.W__plus__,P.YF3Le3):'(((-2*ee**2*MW**2)/sw**2 + (ee**2*MYF3Le3**2)/sw**2 + (ee**2*MYF3Le3**4)/(MW**2*sw**2) - (6*ee**2*MYF3Le3*MYF3Ln3)/sw**2 + (ee**2*MYF3Ln3**2)/sw**2 - (2*ee**2*MYF3Le3**2*MYF3Ln3**2)/(MW**2*sw**2) + (ee**2*MYF3Ln3**4)/(MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYF3Le3**2 + MYF3Le3**4 - 2*MW**2*MYF3Ln3**2 - 2*MYF3Le3**2*MYF3Ln3**2 + MYF3Ln3**4))/(32.*cmath.pi*abs(MYF3Ln3)**3)',
                                       (P.Xc,P.vt):'((-MXc**2 + MYF3Ln3**2)*(-(lamF3L3x3**2*MXc**2) + lamF3L3x3**2*MYF3Ln3**2))/(32.*cmath.pi*abs(MYF3Ln3)**3)',
                                       (P.Xs,P.vt):'((-MXs**2 + MYF3Ln3**2)*(-(lamF3L3x3**2*MXs**2) + lamF3L3x3**2*MYF3Ln3**2))/(32.*cmath.pi*abs(MYF3Ln3)**3)',
                                       (P.Xv,P.vt):'((-MXv**2 + MYF3Ln3**2)*(-2*lamF3L3x3**2*MXv**2 + lamF3L3x3**2*MYF3Ln3**2 + (lamF3L3x3**2*MYF3Ln3**4)/MXv**2))/(32.*cmath.pi*abs(MYF3Ln3)**3)',
                                       (P.Xw,P.vt):'((-MXw**2 + MYF3Ln3**2)*(-2*lamF3L3x3**2*MXw**2 + lamF3L3x3**2*MYF3Ln3**2 + (lamF3L3x3**2*MYF3Ln3**4)/MXw**2))/(32.*cmath.pi*abs(MYF3Ln3)**3)'})

Decay_YS3e1 = Decay(name = 'Decay_YS3e1',
                    particle = P.YS3e1,
                    partial_widths = {(P.e__minus__,P.Xd__tilde__):'((-(lamS3e1x1**2*Me**2) - lamS3e1x1**2*MXd**2 + lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3e1**2 - 2*MXd**2*MYS3e1**2 + MYS3e1**4))/(16.*cmath.pi*abs(MYS3e1)**3)',
                                      (P.e__minus__,P.Xm):'((-(lamS3e1x1**2*Me**2) - lamS3e1x1**2*MXm**2 + lamS3e1x1**2*MYS3e1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3e1**2 - 2*MXm**2*MYS3e1**2 + MYS3e1**4))/(16.*cmath.pi*abs(MYS3e1)**3)'})

Decay_YS3e2 = Decay(name = 'Decay_YS3e2',
                    particle = P.YS3e2,
                    partial_widths = {(P.mu__minus__,P.Xd__tilde__):'((-(lamS3e2x2**2*MMU**2) - lamS3e2x2**2*MXd**2 + lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3e2**2 - 2*MXd**2*MYS3e2**2 + MYS3e2**4))/(16.*cmath.pi*abs(MYS3e2)**3)',
                                      (P.mu__minus__,P.Xm):'((-(lamS3e2x2**2*MMU**2) - lamS3e2x2**2*MXm**2 + lamS3e2x2**2*MYS3e2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3e2**2 - 2*MXm**2*MYS3e2**2 + MYS3e2**4))/(16.*cmath.pi*abs(MYS3e2)**3)'})

Decay_YS3e3 = Decay(name = 'Decay_YS3e3',
                    particle = P.YS3e3,
                    partial_widths = {(P.ta__minus__,P.Xd__tilde__):'((-(lamS3e3x3**2*MTA**2) - lamS3e3x3**2*MXd**2 + lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3e3**2 - 2*MXd**2*MYS3e3**2 + MYS3e3**4))/(16.*cmath.pi*abs(MYS3e3)**3)',
                                      (P.ta__minus__,P.Xm):'((-(lamS3e3x3**2*MTA**2) - lamS3e3x3**2*MXm**2 + lamS3e3x3**2*MYS3e3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3e3**2 - 2*MXm**2*MYS3e3**2 + MYS3e3**4))/(16.*cmath.pi*abs(MYS3e3)**3)'})

Decay_YS3Le1 = Decay(name = 'Decay_YS3Le1',
                     particle = P.YS3Le1,
                     partial_widths = {(P.e__minus__,P.Xd__tilde__):'((-(lamS3L1x1**2*Me**2) - lamS3L1x1**2*MXd**2 + lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXd**2 + MXd**4 - 2*Me**2*MYS3Le1**2 - 2*MXd**2*MYS3Le1**2 + MYS3Le1**4))/(16.*cmath.pi*abs(MYS3Le1)**3)',
                                       (P.e__minus__,P.Xm):'((-(lamS3L1x1**2*Me**2) - lamS3L1x1**2*MXm**2 + lamS3L1x1**2*MYS3Le1**2)*cmath.sqrt(Me**4 - 2*Me**2*MXm**2 + MXm**4 - 2*Me**2*MYS3Le1**2 - 2*MXm**2*MYS3Le1**2 + MYS3Le1**4))/(16.*cmath.pi*abs(MYS3Le1)**3)',
                                       (P.W__minus__,P.YS3Ln1):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le1**2)/sw**2 + (ee**2*MYS3Le1**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln1**2)/sw**2 - (ee**2*MYS3Le1**2*MYS3Ln1**2)/(MW**2*sw**2) + (ee**2*MYS3Ln1**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le1**2 + MYS3Le1**4 - 2*MW**2*MYS3Ln1**2 - 2*MYS3Le1**2*MYS3Ln1**2 + MYS3Ln1**4))/(16.*cmath.pi*abs(MYS3Le1)**3)'})

Decay_YS3Le2 = Decay(name = 'Decay_YS3Le2',
                     particle = P.YS3Le2,
                     partial_widths = {(P.mu__minus__,P.Xd__tilde__):'((-(lamS3L2x2**2*MMU**2) - lamS3L2x2**2*MXd**2 + lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXd**2 + MXd**4 - 2*MMU**2*MYS3Le2**2 - 2*MXd**2*MYS3Le2**2 + MYS3Le2**4))/(16.*cmath.pi*abs(MYS3Le2)**3)',
                                       (P.mu__minus__,P.Xm):'((-(lamS3L2x2**2*MMU**2) - lamS3L2x2**2*MXm**2 + lamS3L2x2**2*MYS3Le2**2)*cmath.sqrt(MMU**4 - 2*MMU**2*MXm**2 + MXm**4 - 2*MMU**2*MYS3Le2**2 - 2*MXm**2*MYS3Le2**2 + MYS3Le2**4))/(16.*cmath.pi*abs(MYS3Le2)**3)',
                                       (P.W__minus__,P.YS3Ln2):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le2**2)/sw**2 + (ee**2*MYS3Le2**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln2**2)/sw**2 - (ee**2*MYS3Le2**2*MYS3Ln2**2)/(MW**2*sw**2) + (ee**2*MYS3Ln2**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le2**2 + MYS3Le2**4 - 2*MW**2*MYS3Ln2**2 - 2*MYS3Le2**2*MYS3Ln2**2 + MYS3Ln2**4))/(16.*cmath.pi*abs(MYS3Le2)**3)'})

Decay_YS3Le3 = Decay(name = 'Decay_YS3Le3',
                     particle = P.YS3Le3,
                     partial_widths = {(P.ta__minus__,P.Xd__tilde__):'((-(lamS3L3x3**2*MTA**2) - lamS3L3x3**2*MXd**2 + lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXd**2 + MXd**4 - 2*MTA**2*MYS3Le3**2 - 2*MXd**2*MYS3Le3**2 + MYS3Le3**4))/(16.*cmath.pi*abs(MYS3Le3)**3)',
                                       (P.ta__minus__,P.Xm):'((-(lamS3L3x3**2*MTA**2) - lamS3L3x3**2*MXm**2 + lamS3L3x3**2*MYS3Le3**2)*cmath.sqrt(MTA**4 - 2*MTA**2*MXm**2 + MXm**4 - 2*MTA**2*MYS3Le3**2 - 2*MXm**2*MYS3Le3**2 + MYS3Le3**4))/(16.*cmath.pi*abs(MYS3Le3)**3)',
                                       (P.W__minus__,P.YS3Ln3):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le3**2)/sw**2 + (ee**2*MYS3Le3**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln3**2)/sw**2 - (ee**2*MYS3Le3**2*MYS3Ln3**2)/(MW**2*sw**2) + (ee**2*MYS3Ln3**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le3**2 + MYS3Le3**4 - 2*MW**2*MYS3Ln3**2 - 2*MYS3Le3**2*MYS3Ln3**2 + MYS3Ln3**4))/(16.*cmath.pi*abs(MYS3Le3)**3)'})

Decay_YS3Ln1 = Decay(name = 'Decay_YS3Ln1',
                     particle = P.YS3Ln1,
                     partial_widths = {(P.ve,P.Xd__tilde__):'((-MXd**2 + MYS3Ln1**2)*(-(lamS3L1x1**2*MXd**2) + lamS3L1x1**2*MYS3Ln1**2))/(16.*cmath.pi*abs(MYS3Ln1)**3)',
                                       (P.ve,P.Xm):'((-MXm**2 + MYS3Ln1**2)*(-(lamS3L1x1**2*MXm**2) + lamS3L1x1**2*MYS3Ln1**2))/(16.*cmath.pi*abs(MYS3Ln1)**3)',
                                       (P.W__plus__,P.YS3Le1):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le1**2)/sw**2 + (ee**2*MYS3Le1**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln1**2)/sw**2 - (ee**2*MYS3Le1**2*MYS3Ln1**2)/(MW**2*sw**2) + (ee**2*MYS3Ln1**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le1**2 + MYS3Le1**4 - 2*MW**2*MYS3Ln1**2 - 2*MYS3Le1**2*MYS3Ln1**2 + MYS3Ln1**4))/(16.*cmath.pi*abs(MYS3Ln1)**3)'})

Decay_YS3Ln2 = Decay(name = 'Decay_YS3Ln2',
                     particle = P.YS3Ln2,
                     partial_widths = {(P.vm,P.Xd__tilde__):'((-MXd**2 + MYS3Ln2**2)*(-(lamS3L2x2**2*MXd**2) + lamS3L2x2**2*MYS3Ln2**2))/(16.*cmath.pi*abs(MYS3Ln2)**3)',
                                       (P.vm,P.Xm):'((-MXm**2 + MYS3Ln2**2)*(-(lamS3L2x2**2*MXm**2) + lamS3L2x2**2*MYS3Ln2**2))/(16.*cmath.pi*abs(MYS3Ln2)**3)',
                                       (P.W__plus__,P.YS3Le2):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le2**2)/sw**2 + (ee**2*MYS3Le2**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln2**2)/sw**2 - (ee**2*MYS3Le2**2*MYS3Ln2**2)/(MW**2*sw**2) + (ee**2*MYS3Ln2**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le2**2 + MYS3Le2**4 - 2*MW**2*MYS3Ln2**2 - 2*MYS3Le2**2*MYS3Ln2**2 + MYS3Ln2**4))/(16.*cmath.pi*abs(MYS3Ln2)**3)'})

Decay_YS3Ln3 = Decay(name = 'Decay_YS3Ln3',
                     particle = P.YS3Ln3,
                     partial_widths = {(P.vt,P.Xd__tilde__):'((-MXd**2 + MYS3Ln3**2)*(-(lamS3L3x3**2*MXd**2) + lamS3L3x3**2*MYS3Ln3**2))/(16.*cmath.pi*abs(MYS3Ln3)**3)',
                                       (P.vt,P.Xm):'((-MXm**2 + MYS3Ln3**2)*(-(lamS3L3x3**2*MXm**2) + lamS3L3x3**2*MYS3Ln3**2))/(16.*cmath.pi*abs(MYS3Ln3)**3)',
                                       (P.W__plus__,P.YS3Le3):'(((ee**2*MW**2)/(2.*sw**2) - (ee**2*MYS3Le3**2)/sw**2 + (ee**2*MYS3Le3**4)/(2.*MW**2*sw**2) - (ee**2*MYS3Ln3**2)/sw**2 - (ee**2*MYS3Le3**2*MYS3Ln3**2)/(MW**2*sw**2) + (ee**2*MYS3Ln3**4)/(2.*MW**2*sw**2))*cmath.sqrt(MW**4 - 2*MW**2*MYS3Le3**2 + MYS3Le3**4 - 2*MW**2*MYS3Ln3**2 - 2*MYS3Le3**2*MYS3Ln3**2 + MYS3Ln3**4))/(16.*cmath.pi*abs(MYS3Ln3)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.b,P.b__tilde__):'((-7*ee**2*MB**2 + ee**2*MZ**2 - (3*cw**2*ee**2*MB**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) - (17*ee**2*MB**2*sw**2)/(6.*cw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MB**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.c,P.c__tilde__):'((-11*ee**2*MC**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MC**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MC**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MC**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.d,P.d__tilde__):'((-7*ee**2*MD**2 + ee**2*MZ**2 - (3*cw**2*ee**2*MD**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) - (17*ee**2*MD**2*sw**2)/(6.*cw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MD**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.e__minus__,P.e__plus__):'((-5*ee**2*Me**2 - ee**2*MZ**2 - (cw**2*ee**2*Me**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*Me**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*Me**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'((-5*ee**2*MMU**2 - ee**2*MZ**2 - (cw**2*ee**2*MMU**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MMU**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MMU**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.s,P.s__tilde__):'((-7*ee**2*MS**2 + ee**2*MZ**2 - (3*cw**2*ee**2*MS**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) - (17*ee**2*MS**2*sw**2)/(6.*cw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MS**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.t,P.t__tilde__):'((-11*ee**2*MT**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MT**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MT**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((-5*ee**2*MTA**2 - ee**2*MZ**2 - (cw**2*ee**2*MTA**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MTA**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.u,P.u__tilde__):'((-11*ee**2*MU**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MU**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MU**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MU**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ve,P.ve__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vm,P.vm__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vt,P.vt__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.W__minus__,P.W__plus__):'(((-12*cw**2*ee**2*MW**2)/sw**2 - (17*cw**2*ee**2*MZ**2)/sw**2 + (4*cw**2*ee**2*MZ**4)/(MW**2*sw**2) + (cw**2*ee**2*MZ**6)/(4.*MW**4*sw**2))*cmath.sqrt(-4*MW**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3e1,P.YF3e1__tilde__):'(((8*ee**2*MYF3e1**2*sw**2)/cw**2 + (4*ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3e1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3e2,P.YF3e2__tilde__):'(((8*ee**2*MYF3e2**2*sw**2)/cw**2 + (4*ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3e2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3e3,P.YF3e3__tilde__):'(((8*ee**2*MYF3e3**2*sw**2)/cw**2 + (4*ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3e3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Le1,P.YF3Le1__tilde__):'((-4*ee**2*MYF3Le1**2 - 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Le1**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Le1**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Le1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Le2,P.YF3Le2__tilde__):'((-4*ee**2*MYF3Le2**2 - 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Le2**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Le2**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Le2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Le3,P.YF3Le3__tilde__):'((-4*ee**2*MYF3Le3**2 - 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Le3**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Le3**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Le3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Ln1,P.YF3Ln1__tilde__):'((4*ee**2*MYF3Ln1**2 + 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Ln1**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Ln1**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Ln1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Ln2,P.YF3Ln2__tilde__):'((4*ee**2*MYF3Ln2**2 + 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Ln2**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Ln2**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Ln2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YF3Ln3,P.YF3Ln3__tilde__):'((4*ee**2*MYF3Ln3**2 + 2*ee**2*MZ**2 + (2*cw**2*ee**2*MYF3Ln3**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MYF3Ln3**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYF3Ln3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3e1__tilde__,P.YS3e1):'(((-4*ee**2*MYS3e1**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYS3e1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3e2__tilde__,P.YS3e2):'(((-4*ee**2*MYS3e2**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYS3e2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3e3__tilde__,P.YS3e3):'(((-4*ee**2*MYS3e3**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MYS3e3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Le1__tilde__,P.YS3Le1):'((2*ee**2*MYS3Le1**2 - (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Le1**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Le1**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Le1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Le2__tilde__,P.YS3Le2):'((2*ee**2*MYS3Le2**2 - (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Le2**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Le2**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Le2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Le3__tilde__,P.YS3Le3):'((2*ee**2*MYS3Le3**2 - (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Le3**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Le3**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Le3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Ln1__tilde__,P.YS3Ln1):'((-2*ee**2*MYS3Ln1**2 + (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Ln1**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Ln1**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Ln1**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Ln2__tilde__,P.YS3Ln2):'((-2*ee**2*MYS3Ln2**2 + (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Ln2**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Ln2**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Ln2**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.YS3Ln3__tilde__,P.YS3Ln3):'((-2*ee**2*MYS3Ln3**2 + (ee**2*MZ**2)/2. - (cw**2*ee**2*MYS3Ln3**2)/sw**2 + (cw**2*ee**2*MZ**2)/(4.*sw**2) - (ee**2*MYS3Ln3**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/(4.*cw**2))*cmath.sqrt(-4*MYS3Ln3**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)'})

