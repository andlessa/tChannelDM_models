# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 10.4.0 for Mac OS X x86 (64-bit) (February 26, 2016)
# Date: Mon 18 Jan 2021 15:58:17



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
lamF3e1x1 = Parameter(name = 'lamF3e1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.23,
                      texname = '\\text{lamF3e1x1}',
                      lhablock = 'DMF3E',
                      lhacode = [ 1, 1 ])

lamF3e2x2 = Parameter(name = 'lamF3e2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.24,
                      texname = '\\text{lamF3e2x2}',
                      lhablock = 'DMF3E',
                      lhacode = [ 2, 2 ])

lamF3e3x3 = Parameter(name = 'lamF3e3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.25,
                      texname = '\\text{lamF3e3x3}',
                      lhablock = 'DMF3E',
                      lhacode = [ 3, 3 ])

lamF3L1x1 = Parameter(name = 'lamF3L1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.2,
                      texname = '\\text{lamF3L1x1}',
                      lhablock = 'DMF3L',
                      lhacode = [ 1, 1 ])

lamF3L2x2 = Parameter(name = 'lamF3L2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.21,
                      texname = '\\text{lamF3L2x2}',
                      lhablock = 'DMF3L',
                      lhacode = [ 2, 2 ])

lamF3L3x3 = Parameter(name = 'lamF3L3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.22,
                      texname = '\\text{lamF3L3x3}',
                      lhablock = 'DMF3L',
                      lhacode = [ 3, 3 ])

lamS3e1x1 = Parameter(name = 'lamS3e1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.13,
                      texname = '\\text{lamS3e1x1}',
                      lhablock = 'DMS3E',
                      lhacode = [ 1, 1 ])

lamS3e2x2 = Parameter(name = 'lamS3e2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.14,
                      texname = '\\text{lamS3e2x2}',
                      lhablock = 'DMS3E',
                      lhacode = [ 2, 2 ])

lamS3e3x3 = Parameter(name = 'lamS3e3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.15,
                      texname = '\\text{lamS3e3x3}',
                      lhablock = 'DMS3E',
                      lhacode = [ 3, 3 ])

lamS3L1x1 = Parameter(name = 'lamS3L1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.1,
                      texname = '\\text{lamS3L1x1}',
                      lhablock = 'DMS3L',
                      lhacode = [ 1, 1 ])

lamS3L2x2 = Parameter(name = 'lamS3L2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.11,
                      texname = '\\text{lamS3L2x2}',
                      lhablock = 'DMS3L',
                      lhacode = [ 2, 2 ])

lamS3L3x3 = Parameter(name = 'lamS3L3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.12,
                      texname = '\\text{lamS3L3x3}',
                      lhablock = 'DMS3L',
                      lhacode = [ 3, 3 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\alpha _s',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymdo = Parameter(name = 'ymdo',
                 nature = 'external',
                 type = 'real',
                 value = 0.00504,
                 texname = '\\text{ymdo}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 1 ])

ymup = Parameter(name = 'ymup',
                 nature = 'external',
                 type = 'real',
                 value = 0.00255,
                 texname = '\\text{ymup}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 2 ])

yms = Parameter(name = 'yms',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = '\\text{yms}',
                lhablock = 'YUKAWA',
                lhacode = [ 3 ])

ymc = Parameter(name = 'ymc',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = '\\text{ymc}',
                lhablock = 'YUKAWA',
                lhacode = [ 4 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

yme = Parameter(name = 'yme',
                nature = 'external',
                type = 'real',
                value = 0.000511,
                texname = '\\text{yme}',
                lhablock = 'YUKAWA',
                lhacode = [ 11 ])

ymm = Parameter(name = 'ymm',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{ymm}',
                lhablock = 'YUKAWA',
                lhacode = [ 13 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

Me = Parameter(name = 'Me',
               nature = 'external',
               type = 'real',
               value = 0.000511,
               texname = '\\text{Me}',
               lhablock = 'MASS',
               lhacode = [ 11 ])

MMU = Parameter(name = 'MMU',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{MMU}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MU = Parameter(name = 'MU',
               nature = 'external',
               type = 'real',
               value = 0.00255,
               texname = 'M',
               lhablock = 'MASS',
               lhacode = [ 2 ])

MC = Parameter(name = 'MC',
               nature = 'external',
               type = 'real',
               value = 1.27,
               texname = '\\text{MC}',
               lhablock = 'MASS',
               lhacode = [ 4 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MD = Parameter(name = 'MD',
               nature = 'external',
               type = 'real',
               value = 0.00504,
               texname = '\\text{MD}',
               lhablock = 'MASS',
               lhacode = [ 1 ])

MS = Parameter(name = 'MS',
               nature = 'external',
               type = 'real',
               value = 0.101,
               texname = '\\text{MS}',
               lhablock = 'MASS',
               lhacode = [ 3 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

MXm = Parameter(name = 'MXm',
                nature = 'external',
                type = 'real',
                value = 10.,
                texname = '\\text{MXm}',
                lhablock = 'MASS',
                lhacode = [ 52 ])

MXd = Parameter(name = 'MXd',
                nature = 'external',
                type = 'real',
                value = 13.,
                texname = '\\text{MXd}',
                lhablock = 'MASS',
                lhacode = [ 57 ])

MXs = Parameter(name = 'MXs',
                nature = 'external',
                type = 'real',
                value = 11.,
                texname = '\\text{MXs}',
                lhablock = 'MASS',
                lhacode = [ 51 ])

MXc = Parameter(name = 'MXc',
                nature = 'external',
                type = 'real',
                value = 14.,
                texname = '\\text{MXc}',
                lhablock = 'MASS',
                lhacode = [ 56 ])

MXv = Parameter(name = 'MXv',
                nature = 'external',
                type = 'real',
                value = 12.,
                texname = '\\text{MXv}',
                lhablock = 'MASS',
                lhacode = [ 53 ])

MXw = Parameter(name = 'MXw',
                nature = 'external',
                type = 'real',
                value = 15.,
                texname = '\\text{MXw}',
                lhablock = 'MASS',
                lhacode = [ 58 ])

MYS3Le1 = Parameter(name = 'MYS3Le1',
                    nature = 'external',
                    type = 'real',
                    value = 1000.,
                    texname = '\\text{MYS3Le1}',
                    lhablock = 'MASS',
                    lhacode = [ 5930012 ])

MYS3Le2 = Parameter(name = 'MYS3Le2',
                    nature = 'external',
                    type = 'real',
                    value = 1001.,
                    texname = '\\text{MYS3Le2}',
                    lhablock = 'MASS',
                    lhacode = [ 5930014 ])

MYS3Le3 = Parameter(name = 'MYS3Le3',
                    nature = 'external',
                    type = 'real',
                    value = 1002.,
                    texname = '\\text{MYS3Le3}',
                    lhablock = 'MASS',
                    lhacode = [ 5930016 ])

MYS3Ln1 = Parameter(name = 'MYS3Ln1',
                    nature = 'external',
                    type = 'real',
                    value = 1003.,
                    texname = '\\text{MYS3Ln1}',
                    lhablock = 'MASS',
                    lhacode = [ 5930011 ])

MYS3Ln2 = Parameter(name = 'MYS3Ln2',
                    nature = 'external',
                    type = 'real',
                    value = 1004.,
                    texname = '\\text{MYS3Ln2}',
                    lhablock = 'MASS',
                    lhacode = [ 5930013 ])

MYS3Ln3 = Parameter(name = 'MYS3Ln3',
                    nature = 'external',
                    type = 'real',
                    value = 1005.,
                    texname = '\\text{MYS3Ln3}',
                    lhablock = 'MASS',
                    lhacode = [ 5930015 ])

MYS3e1 = Parameter(name = 'MYS3e1',
                   nature = 'external',
                   type = 'real',
                   value = 2003.,
                   texname = '\\text{MYS3e1}',
                   lhablock = 'MASS',
                   lhacode = [ 5940011 ])

MYS3e2 = Parameter(name = 'MYS3e2',
                   nature = 'external',
                   type = 'real',
                   value = 2004.,
                   texname = '\\text{MYS3e2}',
                   lhablock = 'MASS',
                   lhacode = [ 5940013 ])

MYS3e3 = Parameter(name = 'MYS3e3',
                   nature = 'external',
                   type = 'real',
                   value = 2005.,
                   texname = '\\text{MYS3e3}',
                   lhablock = 'MASS',
                   lhacode = [ 5940015 ])

MYF3Le1 = Parameter(name = 'MYF3Le1',
                    nature = 'external',
                    type = 'real',
                    value = 3000.,
                    texname = '\\text{MYF3Le1}',
                    lhablock = 'MASS',
                    lhacode = [ 5910012 ])

MYF3Le2 = Parameter(name = 'MYF3Le2',
                    nature = 'external',
                    type = 'real',
                    value = 3001.,
                    texname = '\\text{MYF3Le2}',
                    lhablock = 'MASS',
                    lhacode = [ 5910014 ])

MYF3Le3 = Parameter(name = 'MYF3Le3',
                    nature = 'external',
                    type = 'real',
                    value = 3002.,
                    texname = '\\text{MYF3Le3}',
                    lhablock = 'MASS',
                    lhacode = [ 5910016 ])

MYF3Ln1 = Parameter(name = 'MYF3Ln1',
                    nature = 'external',
                    type = 'real',
                    value = 3003.,
                    texname = '\\text{MYF3Ln1}',
                    lhablock = 'MASS',
                    lhacode = [ 5910011 ])

MYF3Ln2 = Parameter(name = 'MYF3Ln2',
                    nature = 'external',
                    type = 'real',
                    value = 3004.,
                    texname = '\\text{MYF3Ln2}',
                    lhablock = 'MASS',
                    lhacode = [ 5910013 ])

MYF3Ln3 = Parameter(name = 'MYF3Ln3',
                    nature = 'external',
                    type = 'real',
                    value = 3005.,
                    texname = '\\text{MYF3Ln3}',
                    lhablock = 'MASS',
                    lhacode = [ 5910015 ])

MYF3e1 = Parameter(name = 'MYF3e1',
                   nature = 'external',
                   type = 'real',
                   value = 4003.,
                   texname = '\\text{MYF3e1}',
                   lhablock = 'MASS',
                   lhacode = [ 5920011 ])

MYF3e2 = Parameter(name = 'MYF3e2',
                   nature = 'external',
                   type = 'real',
                   value = 4004.,
                   texname = '\\text{MYF3e2}',
                   lhablock = 'MASS',
                   lhacode = [ 5920013 ])

MYF3e3 = Parameter(name = 'MYF3e3',
                   nature = 'external',
                   type = 'real',
                   value = 4005.,
                   texname = '\\text{MYF3e3}',
                   lhablock = 'MASS',
                   lhacode = [ 5920015 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.00407,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

WYS3Le1 = Parameter(name = 'WYS3Le1',
                    nature = 'external',
                    type = 'real',
                    value = 10.,
                    texname = '\\text{WYS3Le1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930012 ])

WYS3Le2 = Parameter(name = 'WYS3Le2',
                    nature = 'external',
                    type = 'real',
                    value = 11.,
                    texname = '\\text{WYS3Le2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930014 ])

WYS3Le3 = Parameter(name = 'WYS3Le3',
                    nature = 'external',
                    type = 'real',
                    value = 12.,
                    texname = '\\text{WYS3Le3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930016 ])

WYS3Ln1 = Parameter(name = 'WYS3Ln1',
                    nature = 'external',
                    type = 'real',
                    value = 13.,
                    texname = '\\text{WYS3Ln1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930011 ])

WYS3Ln2 = Parameter(name = 'WYS3Ln2',
                    nature = 'external',
                    type = 'real',
                    value = 14.,
                    texname = '\\text{WYS3Ln2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930013 ])

WYS3Ln3 = Parameter(name = 'WYS3Ln3',
                    nature = 'external',
                    type = 'real',
                    value = 15.,
                    texname = '\\text{WYS3Ln3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5930015 ])

WYS3e1 = Parameter(name = 'WYS3e1',
                   nature = 'external',
                   type = 'real',
                   value = 23.,
                   texname = '\\text{WYS3e1}',
                   lhablock = 'DECAY',
                   lhacode = [ 5940011 ])

WYS3e2 = Parameter(name = 'WYS3e2',
                   nature = 'external',
                   type = 'real',
                   value = 24.,
                   texname = '\\text{WYS3e2}',
                   lhablock = 'DECAY',
                   lhacode = [ 5940013 ])

WYS3e3 = Parameter(name = 'WYS3e3',
                   nature = 'external',
                   type = 'real',
                   value = 25.,
                   texname = '\\text{WYS3e3}',
                   lhablock = 'DECAY',
                   lhacode = [ 5940015 ])

WYF3Le1 = Parameter(name = 'WYF3Le1',
                    nature = 'external',
                    type = 'real',
                    value = 30.,
                    texname = '\\text{WYF3Le1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910012 ])

WYF3Le2 = Parameter(name = 'WYF3Le2',
                    nature = 'external',
                    type = 'real',
                    value = 31.,
                    texname = '\\text{WYF3Le2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910014 ])

WYF3Le3 = Parameter(name = 'WYF3Le3',
                    nature = 'external',
                    type = 'real',
                    value = 32.,
                    texname = '\\text{WYF3Le3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910016 ])

WYF3Ln1 = Parameter(name = 'WYF3Ln1',
                    nature = 'external',
                    type = 'real',
                    value = 33.,
                    texname = '\\text{WYF3Ln1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910011 ])

WYF3Ln2 = Parameter(name = 'WYF3Ln2',
                    nature = 'external',
                    type = 'real',
                    value = 34.,
                    texname = '\\text{WYF3Ln2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910013 ])

WYF3Ln3 = Parameter(name = 'WYF3Ln3',
                    nature = 'external',
                    type = 'real',
                    value = 35.,
                    texname = '\\text{WYF3Ln3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910015 ])

WYF3e1 = Parameter(name = 'WYF3e1',
                   nature = 'external',
                   type = 'real',
                   value = 43.,
                   texname = '\\text{WYF3e1}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920011 ])

WYF3e2 = Parameter(name = 'WYF3e2',
                   nature = 'external',
                   type = 'real',
                   value = 44.,
                   texname = '\\text{WYF3e2}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920013 ])

WYF3e3 = Parameter(name = 'WYF3e3',
                   nature = 'external',
                   type = 'real',
                   value = 45.,
                   texname = '\\text{WYF3e3}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920015 ])

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

G = Parameter(name = 'G',
              nature = 'internal',
              type = 'real',
              value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
              texname = 'G')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
               texname = 'M_W')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = 'c_w')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = 's_w')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = 'g_1')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = 'g_w')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = '(2*MW*sw)/ee',
                texname = '\\text{vev}')

lam = Parameter(name = 'lam',
                nature = 'internal',
                type = 'real',
                value = 'MH**2/(2.*vev**2)',
                texname = '\\text{lam}')

yb = Parameter(name = 'yb',
               nature = 'internal',
               type = 'real',
               value = '(ymb*cmath.sqrt(2))/vev',
               texname = '\\text{yb}')

yc = Parameter(name = 'yc',
               nature = 'internal',
               type = 'real',
               value = '(ymc*cmath.sqrt(2))/vev',
               texname = '\\text{yc}')

ydo = Parameter(name = 'ydo',
                nature = 'internal',
                type = 'real',
                value = '(ymdo*cmath.sqrt(2))/vev',
                texname = '\\text{ydo}')

ye = Parameter(name = 'ye',
               nature = 'internal',
               type = 'real',
               value = '(yme*cmath.sqrt(2))/vev',
               texname = '\\text{ye}')

ym = Parameter(name = 'ym',
               nature = 'internal',
               type = 'real',
               value = '(ymm*cmath.sqrt(2))/vev',
               texname = '\\text{ym}')

ys = Parameter(name = 'ys',
               nature = 'internal',
               type = 'real',
               value = '(yms*cmath.sqrt(2))/vev',
               texname = '\\text{ys}')

yt = Parameter(name = 'yt',
               nature = 'internal',
               type = 'real',
               value = '(ymt*cmath.sqrt(2))/vev',
               texname = '\\text{yt}')

ytau = Parameter(name = 'ytau',
                 nature = 'internal',
                 type = 'real',
                 value = '(ymtau*cmath.sqrt(2))/vev',
                 texname = '\\text{ytau}')

yup = Parameter(name = 'yup',
                nature = 'internal',
                type = 'real',
                value = '(ymup*cmath.sqrt(2))/vev',
                texname = '\\text{yup}')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sqrt(lam*vev**2)',
                texname = '\\mu')

